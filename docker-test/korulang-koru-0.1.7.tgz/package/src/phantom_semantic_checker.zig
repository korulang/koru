// Phantom Semantic Checker - Validates module-qualified phantom states
const log = @import("log");
const std = @import("std");
const ast = @import("ast");
const errors = @import("errors");
const phantom_parser = @import("phantom_parser");

// Access compiler flags via root (backend.zig generates CompilerEnv)
const root = @import("root");
const CompilerEnv = if (@hasDecl(root, "CompilerEnv")) root.CompilerEnv else struct {
    // Fallback for unit tests where CompilerEnv doesn't exist
    // Returns false - strict-base-types is off by default
    pub fn hasFlag(_: []const u8) bool {
        return false;
    }
};

/// Checks that module-qualified phantom states reference valid imported modules
pub const PhantomSemanticChecker = struct {
    allocator: std.mem.Allocator,
    reporter: *errors.ErrorReporter,
    module_map: std.StringHashMap([]const u8),
    label_map: std.StringHashMap(*const ast.EventDecl),
    disposal_event_map: std.StringHashMap(DisposalEventInfo),

    /// Information about an event for disposal suggestions
    const DisposalEventInfo = struct {
        decl: *const ast.EventDecl,
        module_name: []const u8,
    };

    pub fn init(allocator: std.mem.Allocator, reporter: *errors.ErrorReporter) !PhantomSemanticChecker {
        return PhantomSemanticChecker{
            .allocator = allocator,
            .reporter = reporter,
            .module_map = std.StringHashMap([]const u8).init(allocator),
            .label_map = std.StringHashMap(*const ast.EventDecl).init(allocator),
            .disposal_event_map = std.StringHashMap(DisposalEventInfo).init(allocator),
        };
    }

    pub fn deinit(self: *PhantomSemanticChecker) void {
        // Free allocated disposal event map keys
        var iter = self.disposal_event_map.iterator();
        while (iter.next()) |entry| {
            self.allocator.free(entry.key_ptr.*);
        }
        self.disposal_event_map.deinit();
        self.module_map.deinit();
        self.label_map.deinit();
    }

    /// Check phantom types in the entire AST
    pub fn check(self: *PhantomSemanticChecker, source_ast: *const ast.Program) !void {
        log.debug("\n[PHANTOM-CHECK] Starting phantom semantic check for program with {d} items\n", .{source_ast.items.len});
        // Track if we found any errors (but continue checking to find all of them)
        var has_errors = false;

        // Pass 1: Build module resolution map from imports
        try self.buildModuleMap(source_ast);

        // Build event map for disposal suggestions
        try self.buildDisposalEventMap(source_ast);

        // Reset label map for this run
        self.label_map.clearRetainingCapacity();

        // Pass 1: Validate all phantom annotations (syntax, modules exist)
        const annotations_valid = try self.validatePhantomAnnotations(source_ast);
        if (!annotations_valid) {
            has_errors = true;
            // Continue checking for more errors
        }

        // Pass 2: Validate phantom state flows (compatibility checking)
        // Reset label map for each check run
        self.label_map.clearRetainingCapacity();
        const flows_valid = try self.validatePhantomFlows(source_ast);
        if (!flows_valid) {
            has_errors = true;
            // Continue checking for more errors
        }

        // Return error if we found any issues
        if (has_errors) {
            log.debug("[PHANTOM] Returning ValidationFailed - annotations_valid={}, flows_valid={}\n", .{ annotations_valid, flows_valid });
            return error.ValidationFailed;
        }
        log.debug("[PHANTOM] All validation passed!\n", .{});
    }

    fn buildModuleMap(self: *PhantomSemanticChecker, source_ast: *const ast.Program) !void {
        for (source_ast.items) |item| {
            switch (item) {
                .import_decl => |imp| {
                    const local_name = imp.local_name orelse imp.path;
                    try self.module_map.put(local_name, imp.path);
                },
                .module_decl => |mod| {
                    // Map logical name to logical name (for phantom state canonicalization)
                    // We want "app.fs:opened" not "tests/.../fs.kz:opened"
                    try self.module_map.put(mod.logical_name, mod.logical_name);
                },
                else => {},
            }
        }
    }

    /// Build a map of all events for disposal suggestions
    fn buildDisposalEventMap(self: *PhantomSemanticChecker, source_ast: *const ast.Program) !void {
        for (source_ast.items) |item| {
            switch (item) {
                .event_decl => |*event_decl| {
                    const qualified_name = try self.buildDisposalQualifiedEventName(event_decl);
                    try self.disposal_event_map.put(qualified_name, .{
                        .decl = event_decl,
                        .module_name = event_decl.module,
                    });
                },
                .module_decl => |mod| {
                    // Add events from submodules - use module's logical_name for full path
                    // Use index-based iteration to get stable pointers
                    for (mod.items, 0..) |_, idx| {
                        switch (mod.items[idx]) {
                            .event_decl => |*event_decl| {
                                const qualified_name = try self.buildDisposalQualifiedEventNameWithModule(event_decl, mod.logical_name);
                                try self.disposal_event_map.put(qualified_name, .{
                                    .decl = event_decl,
                                    .module_name = mod.logical_name,
                                });
                            },
                            else => {},
                        }
                    }
                },
                else => {},
            }
        }
    }

    /// Build qualified event name like "module:event" or "module:event[!]"
    fn buildDisposalQualifiedEventName(self: *PhantomSemanticChecker, event_decl: *const ast.EventDecl) ![]const u8 {
        return self.buildDisposalQualifiedEventNameWithModule(event_decl, event_decl.module);
    }

    /// Build qualified event name with explicit module name
    fn buildDisposalQualifiedEventNameWithModule(self: *PhantomSemanticChecker, event_decl: *const ast.EventDecl, module_name: []const u8) ![]const u8 {
        const event_name = event_decl.path.segments[0];
        const has_default = for (event_decl.annotations) |ann| {
            if (std.mem.eql(u8, ann, "!")) break true;
        } else false;

        if (has_default) {
            return std.fmt.allocPrint(self.allocator, "{s}:{s}[!]", .{ module_name, event_name });
        } else {
            return std.fmt.allocPrint(self.allocator, "{s}:{s}", .{ module_name, event_name });
        }
    }

    /// Find events that can discharge a given phantom state obligation
    /// Returns a list of event names that consume the given phantom state
    fn findDisposalEventsForState(self: *PhantomSemanticChecker, phantom_state: []const u8) !std.ArrayList([]const u8) {
        var results = try std.ArrayList([]const u8).initCapacity(self.allocator, 4);

        // Strip the ! suffix to get base state
        var base_state = phantom_state;
        if (std.mem.endsWith(u8, base_state, "!")) {
            base_state = base_state[0 .. base_state.len - 1];
        }

        // Search all events for [!state] parameters
        var iter = self.disposal_event_map.iterator();
        while (iter.next()) |entry| {
            const event_decl = entry.value_ptr.decl;

            for (event_decl.input.fields) |field| {
                if (field.phantom) |field_phantom| {
                    // Parse to check if it consumes this state
                    var parsed = phantom_parser.PhantomState.parse(self.allocator, field_phantom) catch continue;
                    defer parsed.deinit(self.allocator);

                    switch (parsed) {
                        .concrete => |concrete| {
                            if (concrete.consumes_obligation) {
                                // Build full state name - canonicalize using event's module if no module specified
                                const consumer_state = if (concrete.module_path) |mod|
                                    try std.fmt.allocPrint(self.allocator, "{s}:{s}", .{ mod, concrete.name })
                                else
                                    try std.fmt.allocPrint(self.allocator, "{s}:{s}", .{ entry.value_ptr.module_name, concrete.name });
                                defer self.allocator.free(consumer_state);

                                if (std.mem.eql(u8, consumer_state, base_state)) {
                                    // Use full qualified name (e.g., "app.db:begin")
                                    try results.append(self.allocator, try self.allocator.dupe(u8, entry.key_ptr.*));
                                }
                            }
                        },
                        .variable => {},
                        .state_union => |u| {
                            for (u.members) |member| {
                                if (!member.consumes_obligation) continue;
                                const consumer_state = if (member.module_path) |mod|
                                    try std.fmt.allocPrint(self.allocator, "{s}:{s}", .{ mod, member.name })
                                else
                                    try std.fmt.allocPrint(self.allocator, "{s}:{s}", .{ entry.value_ptr.module_name, member.name });
                                defer self.allocator.free(consumer_state);

                                if (std.mem.eql(u8, consumer_state, base_state)) {
                                    // Use full qualified name (e.g., "app.db:begin")
                                    try results.append(self.allocator, try self.allocator.dupe(u8, entry.key_ptr.*));
                                    break;
                                }
                            }
                        },
                    }
                }
            }
        }

        return results;
    }

    fn validatePhantomAnnotations(self: *PhantomSemanticChecker, source_ast: *const ast.Program) !bool {
        var has_errors = false;

        for (source_ast.items) |item| {
            switch (item) {
                .event_decl => |event_decl| {
                    // Check input fields
                    for (event_decl.input.fields) |field| {
                        if (field.phantom) |phantom_str| {
                            const phantom_valid = try self.validatePhantom(phantom_str, event_decl.path.segments[0], event_decl.location, true);
                            if (!phantom_valid) {
                                has_errors = true;
                                // Continue checking for more errors
                            }
                        }
                    }

                    // Check branch output fields
                    for (event_decl.branches) |branch| {
                        for (branch.payload.fields) |field| {
                            if (field.phantom) |phantom_str| {
                                const phantom_valid = try self.validatePhantom(phantom_str, event_decl.path.segments[0], event_decl.location, false);
                                if (!phantom_valid) {
                                    has_errors = true;
                                    // Continue checking for more errors
                                }
                            }
                        }
                    }
                },
                .module_decl => |module| {
                    // Check events in imported library modules
                    for (module.items) |mod_item| {
                        if (mod_item == .event_decl) {
                            const event_decl = mod_item.event_decl;

                            for (event_decl.input.fields) |field| {
                                if (field.phantom) |phantom_str| {
                                    const phantom_valid = try self.validatePhantom(phantom_str, event_decl.path.segments[0], event_decl.location, true);
                                    if (!phantom_valid) {
                                        has_errors = true;
                                        // Continue checking for more errors
                                    }
                                }
                            }

                            for (event_decl.branches) |branch| {
                                for (branch.payload.fields) |field| {
                                    if (field.phantom) |phantom_str| {
                                        const phantom_valid = try self.validatePhantom(phantom_str, event_decl.path.segments[0], event_decl.location, false);
                                        if (!phantom_valid) {
                                            has_errors = true;
                                            // Continue checking for more errors
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                else => {},
            }
        }

        return !has_errors;
    }

    fn validatePhantom(self: *PhantomSemanticChecker, phantom_str: []const u8, event_name: []const u8, location: errors.SourceLocation, is_input: bool) !bool {
        var phantom = try phantom_parser.PhantomState.parse(self.allocator, phantom_str);
        defer phantom.deinit(self.allocator);

        switch (phantom) {
            .concrete => |concrete| {
                // Check for obligation issuance (! suffix) on input - this is invalid
                // You can only ISSUE obligations on outputs, not inputs
                if (is_input and concrete.requires_cleanup) {
                    try self.reporter.addError(
                        .KORU033,
                        location.line,
                        location.column,
                        "Cannot issue obligation '[{s}]' on input parameter (event: {s}). Use '[!{s}]' to consume an existing obligation, or remove the '!' suffix.",
                        .{ phantom_str, event_name, concrete.name },
                    );
                    return false;
                }

                // Check for obligation consumption (! prefix) on output - this is invalid
                // You can only CONSUME obligations on inputs, not outputs
                if (!is_input and concrete.consumes_obligation) {
                    try self.reporter.addError(
                        .KORU033,
                        location.line,
                        location.column,
                        "Cannot consume obligation '[{s}]' on output parameter (event: {s}). Use '[{s}!]' to issue a new obligation, or remove the '!' prefix.",
                        .{ phantom_str, event_name, concrete.name },
                    );
                    return false;
                }

                if (concrete.module_path) |mod_path| {
                    if (!self.module_map.contains(mod_path)) {
                        try self.reporter.addError(
                            .KORU040, // Unknown event/proc/subflow - using for unknown module
                            location.line,
                            location.column,
                            "Unknown module '{s}' in phantom type annotation '{s}' (event: {s}). Module not imported.",
                            .{ mod_path, phantom_str, event_name },
                        );
                        // Return false to indicate error, but don't stop checking
                        return false;
                    }
                }
            },
            .variable => {
                // State variables are always valid (they're constraints, not concrete states)
            },
            .state_union => |u| {
                // State unions can only appear on inputs (they accept multiple states)
                // The phantom_parser already rejects unions with ! suffix (requires_cleanup)
                // Validate each member of the union
                for (u.members) |member| {
                    if (member.module_path) |mod_path| {
                        if (!self.module_map.contains(mod_path)) {
                            try self.reporter.addError(
                                .KORU040,
                                location.line,
                                location.column,
                                "Unknown module '{s}' in phantom type annotation '{s}' (event: {s}). Module not imported.",
                                .{ mod_path, phantom_str, event_name },
                            );
                            return false;
                        }
                    }
                }
            },
        }

        return true;
    }

    // ========================================================================
    // Pass 2: Flow Analysis - Phantom State Compatibility Checking
    // ========================================================================

    /// Canonicalize a base type to its fully-qualified form
    ///
    /// Examples:
    ///   - "*Connection" in module "app.db" → "app.db:*Connection"
    ///   - "*User" with field.module_path "app.users" → "app.users:*User"
    ///
    /// This ensures base types from different modules with the same name
    /// are correctly distinguished during comparison.
    fn canonicalizeBaseType(
        self: *PhantomSemanticChecker,
        base_type: []const u8,
        field_module_path: ?[]const u8,
        defining_module: []const u8,
    ) ![]const u8 {
        // If the field has an explicit module path (cross-module type reference),
        // resolve it through module_map. Otherwise use the defining module.
        const canonical_module = if (field_module_path) |mod_path| blk: {
            if (self.module_map.get(mod_path)) |canonical| {
                break :blk canonical;
            } else {
                // Module not found in map - use as-is
                break :blk mod_path;
            }
        } else defining_module;

        return try std.fmt.allocPrint(
            self.allocator,
            "{s}:{s}",
            .{ canonical_module, base_type },
        );
    }

    /// Canonicalize a phantom state to its fully-qualified form
    ///
    /// Examples:
    ///   - *File[open] in module "lib/fileops" → *File[lib/fileops:open]
    ///   - *File[fs:open] where fs→"koru/std/fs" → *File[koru/std/fs:open]
    ///   - *File[koru/std/fs:open] → *File[koru/std/fs:open] (already canonical)
    fn canonicalizePhantomState(
        self: *PhantomSemanticChecker,
        phantom_str: []const u8,
        defining_module: []const u8,
    ) ![]const u8 {
        var phantom = try phantom_parser.PhantomState.parse(self.allocator, phantom_str);
        defer phantom.deinit(self.allocator);

        switch (phantom) {
            .concrete => |concrete| {
                const canonical_module = if (concrete.module_path) |mod_path| blk: {
                    // Already has module qualifier - resolve it through module_map
                    if (self.module_map.get(mod_path)) |canonical| {
                        break :blk canonical;
                    } else {
                        // Module not found - use as-is (error will be caught in validation)
                        break :blk mod_path;
                    }
                } else blk: {
                    // No module qualifier - use the defining module
                    break :blk defining_module;
                };

                // Build canonical form: module:state or module:state!
                const cleanup_suffix = if (concrete.requires_cleanup) "!" else "";
                return try std.fmt.allocPrint(self.allocator, "{s}:{s}{s}", .{ canonical_module, concrete.name, cleanup_suffix });
            },
            .variable => {
                // State variables don't get canonicalized - they're constraints
                return try self.allocator.dupe(u8, phantom_str);
            },
            .state_union => |u| {
                // Canonicalize each member of the union
                var result: std.ArrayListUnmanaged(u8) = .{};
                errdefer result.deinit(self.allocator);

                for (u.members, 0..) |member, i| {
                    if (i > 0) try result.append(self.allocator, '|');
                    // Per-member ! prefix
                    if (member.consumes_obligation) try result.append(self.allocator, '!');

                    const canonical_module = if (member.module_path) |mod_path| blk: {
                        if (self.module_map.get(mod_path)) |canonical| {
                            break :blk canonical;
                        } else {
                            break :blk mod_path;
                        }
                    } else blk: {
                        break :blk defining_module;
                    };

                    // Append module:state
                    try result.appendSlice(self.allocator, canonical_module);
                    try result.append(self.allocator, ':');
                    try result.appendSlice(self.allocator, member.name);
                }

                return result.toOwnedSlice(self.allocator);
            },
        }
    }

    /// Binding context tracks phantom states of variables in scope
    /// Each binding tracks BOTH the phantom state AND the base type
    const BindingContext = struct {
        /// Full type information for a binding
        const BindingInfo = struct {
            phantom_state: []const u8, // e.g., "app.db:active!"
            base_type: []const u8, // e.g., "*Connection"
        };

        bindings: std.StringHashMap(BindingInfo), // variable name → full type info
        cleanup_obligations: std.StringHashMap(void), // track bindings with ! states that need cleanup
        disposed_bindings: std.StringHashMap(void), // track bindings that have been disposed (poisoned)
        outer_scope_obligations: std.StringHashMap(void), // track obligations from outside @scope boundary
        allocator: std.mem.Allocator,

        fn init(allocator: std.mem.Allocator) BindingContext {
            return BindingContext{
                .bindings = std.StringHashMap(BindingInfo).init(allocator),
                .cleanup_obligations = std.StringHashMap(void).init(allocator),
                .disposed_bindings = std.StringHashMap(void).init(allocator),
                .outer_scope_obligations = std.StringHashMap(void).init(allocator),
                .allocator = allocator,
            };
        }

        fn deinit(self: *BindingContext) void {
            var iter = self.bindings.iterator();
            while (iter.next()) |entry| {
                self.allocator.free(entry.key_ptr.*);
                self.allocator.free(entry.value_ptr.phantom_state);
                self.allocator.free(entry.value_ptr.base_type);
            }
            self.bindings.deinit();

            // Free cleanup obligation keys
            var cleanup_iter = self.cleanup_obligations.keyIterator();
            while (cleanup_iter.next()) |key| {
                self.allocator.free(key.*);
            }
            self.cleanup_obligations.deinit();

            // Free disposed binding keys
            var disposed_iter = self.disposed_bindings.keyIterator();
            while (disposed_iter.next()) |key| {
                self.allocator.free(key.*);
            }
            self.disposed_bindings.deinit();

            // Free outer scope obligation keys
            var outer_iter = self.outer_scope_obligations.keyIterator();
            while (outer_iter.next()) |key| {
                self.allocator.free(key.*);
            }
            self.outer_scope_obligations.deinit();
        }

        /// Set a binding with both phantom state and base type
        fn setWithType(self: *BindingContext, name: []const u8, phantom_state: []const u8, base_type: []const u8) !void {
            // Remove old binding if exists
            if (self.bindings.fetchRemove(name)) |kv| {
                self.allocator.free(kv.key);
                self.allocator.free(kv.value.phantom_state);
                self.allocator.free(kv.value.base_type);
            }

            // Add new binding
            const name_copy = try self.allocator.dupe(u8, name);
            const phantom_copy = try self.allocator.dupe(u8, phantom_state);
            const type_copy = try self.allocator.dupe(u8, base_type);
            try self.bindings.put(name_copy, .{
                .phantom_state = phantom_copy,
                .base_type = type_copy,
            });

            // Check if this phantom state has cleanup obligation (! suffix)
            var phantom = try phantom_parser.PhantomState.parse(self.allocator, phantom_state);
            defer phantom.deinit(self.allocator);

            switch (phantom) {
                .concrete => |concrete| {
                    if (concrete.requires_cleanup) {
                        // Track this binding as requiring cleanup
                        const obligation_key = try self.allocator.dupe(u8, name);
                        try self.cleanup_obligations.put(obligation_key, {});
                        log.debug("[CLEANUP] Tracking cleanup obligation for '{s}' with type '{s}[{s}]'\n", .{ name, base_type, phantom_state });
                    }
                },
                .variable => {},
                .state_union => {
                    // State unions cannot have cleanup obligations (they can't be output)
                    // They may have consumes_obligation (! prefix) for input, but that's
                    // handled at invocation time, not binding time
                },
            }
        }

        /// Legacy set function - calls setWithType with empty base type
        /// TODO: Remove this once all callers are updated to use setWithType
        fn set(self: *BindingContext, name: []const u8, phantom_state: []const u8) !void {
            try self.setWithType(name, phantom_state, "");
        }

        /// Get full binding info (phantom state + base type)
        fn getInfo(self: *BindingContext, name: []const u8) ?BindingInfo {
            return self.bindings.get(name);
        }

        /// Get just the phantom state (for backwards compatibility)
        fn get(self: *BindingContext, name: []const u8) ?[]const u8 {
            if (self.bindings.get(name)) |info| {
                return info.phantom_state;
            }
            return null;
        }

        /// Get the base type for a binding
        fn getBaseType(self: *BindingContext, name: []const u8) ?[]const u8 {
            if (self.bindings.get(name)) |info| {
                return info.base_type;
            }
            return null;
        }

        /// Create a child context that inherits parent's state
        fn inherit(parent: *const BindingContext, allocator: std.mem.Allocator) !BindingContext {
            var child = BindingContext.init(allocator);

            // Inherit all bindings (copy full BindingInfo)
            var bind_iter = parent.bindings.iterator();
            while (bind_iter.next()) |entry| {
                const key = try allocator.dupe(u8, entry.key_ptr.*);
                const phantom_copy = try allocator.dupe(u8, entry.value_ptr.phantom_state);
                const type_copy = try allocator.dupe(u8, entry.value_ptr.base_type);
                try child.bindings.put(key, .{
                    .phantom_state = phantom_copy,
                    .base_type = type_copy,
                });
            }

            // Inherit cleanup obligations
            var clean_iter = parent.cleanup_obligations.keyIterator();
            while (clean_iter.next()) |key| {
                const key_copy = try allocator.dupe(u8, key.*);
                try child.cleanup_obligations.put(key_copy, {});
            }

            // Inherit disposed bindings
            var disposed_iter = parent.disposed_bindings.keyIterator();
            while (disposed_iter.next()) |key| {
                const key_copy = try allocator.dupe(u8, key.*);
                try child.disposed_bindings.put(key_copy, {});
            }

            // Inherit outer scope obligations (already marked as outer)
            var outer_iter = parent.outer_scope_obligations.keyIterator();
            while (outer_iter.next()) |key| {
                const key_copy = try allocator.dupe(u8, key.*);
                try child.outer_scope_obligations.put(key_copy, {});
            }

            return child;
        }

        /// Create a child context that marks all inherited cleanup obligations as "outer scope"
        /// Used when entering a @scope boundary - these obligations cannot be satisfied inside the scope
        fn inheritWithScope(parent: *const BindingContext, allocator: std.mem.Allocator) !BindingContext {
            var child = BindingContext.init(allocator);

            // Inherit all bindings (copy full BindingInfo)
            var bind_iter = parent.bindings.iterator();
            while (bind_iter.next()) |entry| {
                const key = try allocator.dupe(u8, entry.key_ptr.*);
                const phantom_copy = try allocator.dupe(u8, entry.value_ptr.phantom_state);
                const type_copy = try allocator.dupe(u8, entry.value_ptr.base_type);
                try child.bindings.put(key, .{
                    .phantom_state = phantom_copy,
                    .base_type = type_copy,
                });
            }

            // Inherit cleanup obligations AND mark them as outer scope
            var clean_iter = parent.cleanup_obligations.keyIterator();
            while (clean_iter.next()) |key| {
                const key_copy = try allocator.dupe(u8, key.*);
                try child.cleanup_obligations.put(key_copy, {});
                // Mark as outer scope - these cannot be satisfied inside @scope
                const outer_key = try allocator.dupe(u8, key.*);
                try child.outer_scope_obligations.put(outer_key, {});
            }

            // Inherit disposed bindings
            var disposed_iter = parent.disposed_bindings.keyIterator();
            while (disposed_iter.next()) |key| {
                const key_copy = try allocator.dupe(u8, key.*);
                try child.disposed_bindings.put(key_copy, {});
            }

            // Also inherit any already-marked outer scope obligations from parent
            var outer_iter = parent.outer_scope_obligations.keyIterator();
            while (outer_iter.next()) |key| {
                if (!child.outer_scope_obligations.contains(key.*)) {
                    const key_copy = try allocator.dupe(u8, key.*);
                    try child.outer_scope_obligations.put(key_copy, {});
                }
            }

            return child;
        }

        /// Remove cleanup obligation for a binding (called when it's properly cleaned up)
        fn clearCleanupObligation(self: *BindingContext, name: []const u8) void {
            if (self.cleanup_obligations.fetchRemove(name)) |kv| {
                self.allocator.free(kv.key);
                log.debug("[CLEANUP] Cleared cleanup obligation for '{s}'\n", .{name});
            }
        }

        /// Mark a binding as disposed (poisoned - cannot be used anymore)
        fn markDisposed(self: *BindingContext, name: []const u8) !void {
            const disposed_key = try self.allocator.dupe(u8, name);
            try self.disposed_bindings.put(disposed_key, {});
            log.debug("[CLEANUP] Marked '{s}' as disposed (poisoned)\n", .{name});
        }

        /// Check if a binding has been disposed
        fn isDisposed(self: *BindingContext, name: []const u8) bool {
            return self.disposed_bindings.contains(name);
        }

        /// Check if there are any uncleaned resources
        fn hasUncleanedResources(self: *BindingContext) bool {
            return self.cleanup_obligations.count() > 0;
        }

        /// Get list of bindings with uncleaned resources (for error reporting)
        fn getUncleanedResources(self: *BindingContext, allocator: std.mem.Allocator) ![][]const u8 {
            const count = self.cleanup_obligations.count();
            if (count == 0) return &[_][]const u8{};

            var list = try allocator.alloc([]const u8, count);
            var iter = self.cleanup_obligations.keyIterator();
            var i: usize = 0;
            while (iter.next()) |key| : (i += 1) {
                list[i] = key.*;
            }
            return list;
        }

        /// Check if there are any outer-scope uncleaned resources
        /// These are obligations from outside a @scope boundary that cannot be satisfied inside
        fn hasOuterScopeObligations(self: *BindingContext) bool {
            // Check if any uncleaned resource is also marked as outer scope
            var iter = self.cleanup_obligations.keyIterator();
            while (iter.next()) |key| {
                if (self.outer_scope_obligations.contains(key.*)) {
                    return true;
                }
            }
            return false;
        }

        /// Get list of outer-scope uncleaned resources (for error reporting)
        fn getOuterScopeObligations(self: *BindingContext, allocator: std.mem.Allocator) ![][]const u8 {
            var count: usize = 0;
            var iter = self.cleanup_obligations.keyIterator();
            while (iter.next()) |key| {
                if (self.outer_scope_obligations.contains(key.*)) {
                    count += 1;
                }
            }
            if (count == 0) return &[_][]const u8{};

            var list = try allocator.alloc([]const u8, count);
            iter = self.cleanup_obligations.keyIterator();
            var i: usize = 0;
            while (iter.next()) |key| {
                if (self.outer_scope_obligations.contains(key.*)) {
                    list[i] = key.*;
                    i += 1;
                }
            }
            return list;
        }

        /// Check if a specific obligation is from outer scope
        fn isOuterScope(self: *BindingContext, name: []const u8) bool {
            return self.outer_scope_obligations.contains(name);
        }
    };

    /// Event info for flow validation
    const EventInfo = struct {
        decl: *const ast.EventDecl,
    };

    fn validatePhantomFlows(self: *PhantomSemanticChecker, source_ast: *const ast.Program) !bool {
        log.debug("[PHANTOM-FLOW] Pass 2: Validating phantom flows\n", .{});

        // Build event map for lookup (module:event → EventInfo)
        var event_map = std.StringHashMap(EventInfo).init(self.allocator);
        defer {
            // Free all the keys we allocated
            var key_iter = event_map.keyIterator();
            while (key_iter.next()) |key| {
                self.allocator.free(key.*);
            }
            event_map.deinit();
        }

        try self.buildEventMap(source_ast, &event_map);
        log.debug("[PHANTOM-FLOW] Built event map with {} events\n", .{event_map.count()});

        // Validate all flows/procs, tracking module context
        return self.validateItems(source_ast.items, &event_map, null);
    }

    fn validateItems(self: *PhantomSemanticChecker, items: []const ast.Item, event_map: *std.StringHashMap(EventInfo), current_module: ?[]const u8) !bool {
        var has_errors = false;

        for (items) |item| {
            switch (item) {
                .flow => |*flow| {
                    if (flow.impl_of) |impl_path| {
                        const module = current_module orelse "input";
                        log.debug("[PHANTOM-FLOW] Validating impl flow in module '{s}'\n", .{module});

                        const impl_event_name = try self.pathToString(impl_path);
                        defer self.allocator.free(impl_event_name);

                        const impl_qualified = try std.fmt.allocPrint(self.allocator, "{s}:{s}", .{ module, impl_event_name });
                        defer self.allocator.free(impl_qualified);

                        const impl_event: ?*const ast.EventDecl = if (event_map.get(impl_qualified)) |info| info.decl else null;

                        if (impl_event) |ev| {
                            log.debug("[PHANTOM-FLOW]   Impl flow implements event: '{s}'\n", .{impl_qualified});
                            _ = ev;
                        } else {
                            log.debug("[PHANTOM-FLOW]   Impl event '{s}' not found in event map\n", .{impl_qualified});
                        }

                        if (!try self.validateFlow(flow, event_map, module, impl_event)) {
                            has_errors = true;
                        }
                    } else {
                        const module = flow.module;
                        log.debug("[PHANTOM-FLOW] Validating flow in module '{s}'\n", .{module});
                        if (!try self.validateFlow(flow, event_map, module, null)) {
                            has_errors = true;
                        }
                    }
                },
                .proc_decl => {},
                .module_decl => |module| {
                    // Recursively validate items in module
                    if (!try self.validateItems(module.items, event_map, module.logical_name)) {
                        has_errors = true;
                    }
                },
                else => {},
            }
        }

        return !has_errors;
    }

    fn buildEventMap(self: *PhantomSemanticChecker, source_ast: *const ast.Program, event_map: *std.StringHashMap(EventInfo)) !void {
        // Build event map from both top-level events (user code) and module events (libraries)
        for (source_ast.items) |*item| {
            switch (item.*) {
                .event_decl => |*event_decl| {
                    // Top-level event (user code) - use event.module metadata
                    const event_name = try self.pathToString(event_decl.path);
                    defer self.allocator.free(event_name);

                    // Store with module:event format (using : separator, not .)
                    const qualified_name = try std.fmt.allocPrint(self.allocator, "{s}:{s}", .{ event_decl.module, event_name });
                    try event_map.put(qualified_name, EventInfo{ .decl = event_decl });
                },
                .module_decl => |module| {
                    // Events in imported library modules
                    for (module.items) |*mod_item| {
                        if (mod_item.* == .event_decl) {
                            const event_decl = &mod_item.event_decl;
                            const event_name = try self.pathToString(event_decl.path);
                            defer self.allocator.free(event_name);

                            // Store with module:event format (using : separator, not .)
                            const qualified_name = try std.fmt.allocPrint(self.allocator, "{s}:{s}", .{ module.logical_name, event_name });
                            try event_map.put(qualified_name, EventInfo{ .decl = event_decl });
                        }
                    }
                },
                else => {},
            }
        }
    }

    fn validateFlow(
        self: *PhantomSemanticChecker,
        flow: *const ast.Flow,
        event_map: *std.StringHashMap(EventInfo),
        current_module: []const u8,
        implementing_event: ?*const ast.EventDecl, // Event this flow implements (for branch_constructor escape checking)
    ) !bool {
        // Skip flows that have been transformed by [transform] events.
        // Transformed flows have valid structure by construction - the transform
        // replaced the comptime event structure with a runtime node structure.
        for (flow.invocation.annotations) |ann| {
            if (std.mem.startsWith(u8, ann, "@pass_ran")) {
                return true; // Valid - transform output is correct by construction
            }
        }

        var has_errors = false;

        // Get the event name from path segments
        const event_name = try self.pathToString(flow.invocation.path);
        defer self.allocator.free(event_name);

        // Determine the module - use module_qualifier if present, otherwise current_module
        const module_name = flow.invocation.path.module_qualifier orelse current_module;

        // Build fully-qualified event name (module:event)
        const qualified_name = try std.fmt.allocPrint(self.allocator, "{s}:{s}", .{ module_name, event_name });
        defer self.allocator.free(qualified_name);

        log.debug("[PHANTOM-FLOW]   Flow invokes: '{s}' in module '{s}' → qualified: '{s}'\n", .{ event_name, module_name, qualified_name });

        const event_info = event_map.get(qualified_name) orelse {
            log.debug("[PHANTOM-FLOW]   Event '{s}' not found in map, skipping\n", .{qualified_name});
            // Event not found - shape_checker will catch this, we just skip
            return true;
        };

        log.debug("[PHANTOM-FLOW]   Found event '{s}', validating continuations\n", .{qualified_name});

        // For each continuation, validate phantom state flows
        // Pass both: current_module (where flow is defined, for name resolution)
        // and module_name (where event is defined, for phantom qualification)
        for (flow.continuations) |*cont_ptr| {
            const cont_valid = try self.validateContinuation(cont_ptr, event_info.decl, module_name, current_module, event_map, flow.location, null, implementing_event);
            if (!cont_valid) {
                has_errors = true;
                // Continue checking for more errors
            }
        }

        return !has_errors;
    }

    fn validateContinuation(
        self: *PhantomSemanticChecker,
        cont: *const ast.Continuation,
        event_decl: *const ast.EventDecl,
        event_module: ?[]const u8, // Module where the event is defined (for phantom qualification)
        flow_module: []const u8, // Module where the flow is defined (for name resolution)
        event_map: *std.StringHashMap(EventInfo),
        location: errors.SourceLocation,
        parent_context: ?*const BindingContext, // Optional parent context to inherit from
        implementing_event: ?*const ast.EventDecl, // Event this flow implements (for branch_constructor escape)
    ) anyerror!bool {
        var has_errors = false;

        log.debug("[PHANTOM-FLOW]   Continuation branch: '{s}'\n", .{cont.branch});

        // Debug: print event path and branches
        const event_path = try self.pathToString(event_decl.path);
        defer self.allocator.free(event_path);
        log.debug("[PHANTOM-FLOW]   Event has path: '{s}', {} branches:\n", .{ event_path, event_decl.branches.len });
        for (event_decl.branches) |branch| {
            log.debug("[PHANTOM-FLOW]     - '{s}'\n", .{branch.name});
        }

        // Void events (0 branches) have implicit continuations - skip branch validation
        // The continuation just chains to the next event after the void event completes
        if (event_decl.branches.len == 0) {
            log.debug("[PHANTOM-FLOW]   (void event - skipping branch validation)\n", .{});
            // Create binding context for void event continuation
            var void_context = if (parent_context) |parent|
                try BindingContext.inherit(parent, self.allocator)
            else
                BindingContext.init(self.allocator);
            defer void_context.deinit();

            // Still validate the step if present
            if (cont.node) |*step| {
                const step_valid = try self.validateStep(step, &void_context, event_map, flow_module, location);
                if (!step_valid) {
                    return false;
                }

                // If step is an invocation, nested continuations belong to THAT event, not the void parent
                switch (step.*) {
                    .invocation => |*inv| {
                        const step_event_name = try self.pathToString(inv.path);
                        defer self.allocator.free(step_event_name);
                        const step_module = inv.path.module_qualifier orelse flow_module;
                        const step_qualified = try std.fmt.allocPrint(self.allocator, "{s}:{s}", .{ step_module, step_event_name });
                        defer self.allocator.free(step_qualified);

                        if (event_map.get(step_qualified)) |step_event_info| {
                            // Validate nested continuations against the step's event
                            for (cont.continuations) |*nested| {
                                const nested_valid = try self.validateContinuation(nested, step_event_info.decl, step_module, flow_module, event_map, location, &void_context, implementing_event);
                                if (!nested_valid) {
                                    return false;
                                }
                            }
                            return true;
                        }
                    },
                    else => {},
                }
            }
            // Validate nested continuations recursively (fallback: against void event)
            for (cont.continuations) |*nested| {
                const nested_valid = try self.validateContinuation(nested, event_decl, event_module, flow_module, event_map, location, &void_context, implementing_event);
                if (!nested_valid) {
                    return false;
                }
            }
            return true;
        }

        // Catch-all continuations (|?) don't reference a specific branch
        // They handle all unhandled branches, so skip branch validation
        if (cont.is_catchall) {
            log.debug("[PHANTOM-FLOW]   (catch-all continuation - skipping branch validation)\n", .{});
            // Still validate nested continuations if present
            for (cont.continuations) |*nested| {
                const nested_valid = try self.validateContinuation(nested, event_decl, event_module, flow_module, event_map, location, null, implementing_event);
                if (!nested_valid) {
                    return false;
                }
            }
            return true;
        }

        // Empty-branch continuations (|> ...) are void chain continuations
        // They don't reference a branch - they chain after a void event in the pipeline
        // NOTE: This is different from void EVENTS (0 branches) - this handles the continuation SYNTAX
        if (cont.branch.len == 0) {
            log.debug("[PHANTOM-FLOW]   (empty-branch void chain continuation - handling step/nested)\n", .{});
            // Create binding context for void chain continuation
            var void_chain_context = if (parent_context) |parent|
                try BindingContext.inherit(parent, self.allocator)
            else
                BindingContext.init(self.allocator);
            defer void_chain_context.deinit();

            // Validate the step if present
            if (cont.node) |*step| {
                const step_valid = try self.validateStep(step, &void_chain_context, event_map, flow_module, location);
                if (!step_valid) {
                    return false;
                }

                // If step is an invocation, nested continuations belong to THAT event
                switch (step.*) {
                    .invocation => |*inv| {
                        const step_event_name = try self.pathToString(inv.path);
                        defer self.allocator.free(step_event_name);
                        const step_module = inv.path.module_qualifier orelse flow_module;
                        const step_qualified = try std.fmt.allocPrint(self.allocator, "{s}:{s}", .{ step_module, step_event_name });
                        defer self.allocator.free(step_qualified);

                        if (event_map.get(step_qualified)) |step_event_info| {
                            // Validate nested continuations against the step's event
                            for (cont.continuations) |*nested| {
                                const nested_valid = try self.validateContinuation(nested, step_event_info.decl, step_module, flow_module, event_map, location, &void_chain_context, implementing_event);
                                if (!nested_valid) {
                                    return false;
                                }
                            }
                            return true;
                        }
                    },
                    .inline_code => {
                        // inline_code is a void step (e.g., from print.ln transform)
                        // Nested continuations should still be validated against the PARENT event
                        // (not as a void chain) because they might be branch handlers for a previous invocation
                        // For example: |> work() |> print.ln("...") | done |> ...
                        // The | done |> is a branch of work(), not a void chain
                        for (cont.continuations) |*nested| {
                            const nested_valid = try self.validateContinuation(nested, event_decl, event_module, flow_module, event_map, location, &void_chain_context, implementing_event);
                            if (!nested_valid) {
                                return false;
                            }
                        }
                        return true;
                    },
                    else => {},
                }
            }

            // Fallback: validate nested continuations (no step or unrecognized step)
            for (cont.continuations) |*nested| {
                const nested_valid = try self.validateContinuation(nested, event_decl, event_module, flow_module, event_map, location, &void_chain_context, implementing_event);
                if (!nested_valid) {
                    return false;
                }
            }
            return true;
        }

        // Find the branch in the event declaration
        var branch_payload: ?*const ast.Shape = null;
        var branch_decl: ?*const ast.Branch = null;
        for (event_decl.branches) |*branch| {
            if (std.mem.eql(u8, branch.name, cont.branch)) {
                branch_payload = &branch.payload;
                branch_decl = branch;
                break;
            }
        }

        if (branch_payload == null) {
            // Unknown branch - this is an error!

            // Build list of available branches for error message
            var branch_list = std.ArrayList(u8){};
            defer branch_list.deinit(self.allocator);
            const writer = branch_list.writer(self.allocator);

            for (event_decl.branches, 0..) |branch, i| {
                if (i > 0) try writer.writeAll(", ");
                try writer.print("'{s}'", .{branch.name});
            }

            try self.reporter.addError(.KORU030, // Shape mismatch
                location.line, location.column, "Continuation expects branch '{s}' but event '{s}' only produces: {s}", .{ cont.branch, event_path, branch_list.items });
            return false;
        }

        // Check for @scope annotation on the binding (e.g., | each _[@scope] |>)
        const has_scope = blk: {
            for (cont.binding_annotations) |ann| {
                if (std.mem.eql(u8, ann, "@scope")) {
                    break :blk true;
                }
            }
            break :blk false;
        };

        // Build binding context - inherit from parent if provided
        // If @scope, mark inherited obligations as outer-scope
        var context = if (parent_context) |parent|
            if (has_scope)
                try BindingContext.inheritWithScope(parent, self.allocator)
            else
                try BindingContext.inherit(parent, self.allocator)
        else
            BindingContext.init(self.allocator);
        defer context.deinit();

        // Add binding with phantom states from branch payload
        // If there's no explicit binding, synthesize "_" to track the obligation
        const binding_name = cont.binding orelse "_";
        {
            for (branch_payload.?.fields) |field| {
                if (field.phantom) |phantom_str| {
                    // For identity branches (__type_ref), use just the binding name
                    // since the value IS the binding. For struct branches, use binding.field
                    const is_identity = std.mem.eql(u8, field.name, "__type_ref");
                    const field_path = if (is_identity)
                        try self.allocator.dupe(u8, binding_name)
                    else
                        try std.fmt.allocPrint(self.allocator, "{s}.{s}", .{ binding_name, field.name });
                    defer self.allocator.free(field_path);

                    // Canonicalize phantom state using event's qualified module name
                    const module_for_canon = event_module orelse event_decl.module;
                    const canonical_phantom = try self.canonicalizePhantomState(phantom_str, module_for_canon);
                    defer self.allocator.free(canonical_phantom);

                    // Canonicalize base type using field's module_path or defining module
                    const canonical_base_type = try self.canonicalizeBaseType(
                        field.type,
                        field.module_path,
                        module_for_canon,
                    );
                    defer self.allocator.free(canonical_base_type);

                    // Store both phantom state AND base type (both canonicalized)
                    try context.setWithType(field_path, canonical_phantom, canonical_base_type);
                }
            }
        }

        // Add branch-level phantoms (context state)
        if (branch_decl) |bd| {
            log.debug("[PHANTOM-FLOW]   Branch '{s}' has {} annotations\n", .{ bd.name, bd.annotations.len });
            for (bd.annotations, 0..) |ann, i| {
                log.debug("[PHANTOM-FLOW]     Branch Annotation[{}]: '{s}' (isPhantom={})\n", .{ i, ann, isPhantomAnnotation(ann) });
                if (isPhantomAnnotation(ann)) {
                    const module_for_canon = event_module orelse event_decl.module;
                    const canonical = try self.canonicalizePhantomState(ann, module_for_canon);
                    defer self.allocator.free(canonical);
                    log.debug("[PHANTOM-FLOW]     Storing context phantom for branch '{s}': '{s}' (canonical: '{s}')\n", .{ bd.name, ann, canonical });
                    try context.set("", canonical);
                }
            }
        }

        const step_count: usize = if (cont.node != null) 1 else 0;
        log.debug("[PHANTOM-FLOW]   Pipeline has {} steps\n", .{step_count});
        // Debug: print what's in the pipeline
        if (cont.node) |step| {
            log.debug("[PHANTOM-FLOW]     Step 0: {s}\n", .{@tagName(step)});
        }
        // Validate pipeline steps with this context
        // Use flow_module for name resolution (where the flow is defined)
        if (cont.node) |*step| {
            // If this is a label declaration, record it
            switch (step.*) {
                .label_with_invocation => |lwi| {
                    if (lwi.is_declaration) {
                        // Look up the event being invoked to use its signature for the label
                        const inv_event_name = try self.pathToString(lwi.invocation.path);
                        defer self.allocator.free(inv_event_name);

                        const inv_module_name = lwi.invocation.path.module_qualifier orelse flow_module;
                        const qualified_name = try std.fmt.allocPrint(self.allocator, "{s}:{s}", .{ inv_module_name, inv_event_name });
                        defer self.allocator.free(qualified_name);

                        if (event_map.get(qualified_name)) |inv_info| {
                            log.debug("[PHANTOM-FLOW]   Recording label '#{s}' mapping to event '{s}'\n", .{ lwi.label, qualified_name });
                            try self.label_map.put(lwi.label, inv_info.decl);
                        } else {
                            log.debug("[PHANTOM-FLOW]   WARNING: Label '#{s}' points to unknown event '{s}'\n", .{ lwi.label, qualified_name });
                        }
                    }
                },
                else => {},
            }

            const step_valid = try self.validateStep(step, &context, event_map, flow_module, location);
            if (!step_valid) {
                has_errors = true;
                // Continue checking for more errors
            }
        }

        // Check for terminator: pipeline contains a 'terminal' step, 'branch_constructor' step,
        // OR (empty pipeline AND no nested continuations)
        // Branch constructors are ALSO flow terminators - they end the flow and return a value.
        var is_terminator = cont.node == null and cont.continuations.len == 0;
        if (cont.node) |step| {
            if (step == .terminal or step == .branch_constructor) {
                is_terminator = true;
            }
        }
        if (is_terminator) {
            const terminator_type = if (cont.node) |n| @tagName(n) else "empty";
            log.debug("[CLEANUP] Terminator detected ({s}), checking for uncleaned resources\n", .{terminator_type});
            if (context.hasUncleanedResources()) {
                const uncleaned = try context.getUncleanedResources(self.allocator);
                defer self.allocator.free(uncleaned);

                log.debug("[CLEANUP] Uncleaned resources found: {}\n", .{uncleaned.len});
                for (uncleaned) |resource| {
                    log.debug("[CLEANUP]   - '{s}'\n", .{resource});
                }

                // Determine what fields to check for documented escape.
                // - For terminal (_): NO escape allowed
                // - For branch_constructor: Check the IMPLEMENTING event's branch signature
                // - For other terminators: Fall back to incoming branch_payload
                const is_hard_terminal = if (cont.node) |node| node == .terminal else false;
                const is_branch_constructor = if (cont.node) |node| node == .branch_constructor else false;

                // For branch_constructor, find the return branch's fields from the implementing event
                var return_branch_fields: ?[]const ast.Field = null;
                if (is_branch_constructor) {
                    if (cont.node) |node| {
                        const bc = &node.branch_constructor;
                        log.debug("[CLEANUP] Branch constructor returns '{s}'\n", .{bc.branch_name});

                        if (implementing_event) |impl_ev| {
                            // Find the branch in the implementing event's declaration
                            for (impl_ev.branches) |branch| {
                                if (std.mem.eql(u8, branch.name, bc.branch_name)) {
                                    return_branch_fields = branch.payload.fields;
                                    log.debug("[CLEANUP]   Found return branch '{s}' with {} fields\n", .{ bc.branch_name, branch.payload.fields.len });
                                    break;
                                }
                            }
                            if (return_branch_fields == null) {
                                log.debug("[CLEANUP]   WARNING: Branch '{s}' not found in implementing event\n", .{bc.branch_name});
                            }
                        } else {
                            log.debug("[CLEANUP]   No implementing_event - cannot check return signature\n", .{});
                        }
                    }
                }

                var lost_count: usize = 0;
                var first_lost: ?[]const u8 = null;

                for (uncleaned) |resource| {
                    // Outer-scope obligations are the outer scope's responsibility -
                    // skip them regardless of whether THIS continuation is the @scope
                    // boundary itself or a deeper nested cont inside the boundary.
                    if (context.isOuterScope(resource)) {
                        continue;
                    }
                    // For hard terminals (_), all uncleaned resources are errors
                    var documented_escape = false;

                    // Only check for escape through signature if NOT a hard terminal
                    if (!is_hard_terminal) {
                        // For branch_constructor, check if the VALUE being passed matches the resource
                        if (is_branch_constructor) {
                            if (cont.node) |node| {
                                const bc = &node.branch_constructor;
                                // Identity branch constructors use plain_value instead of fields
                                if (bc.plain_value) |plain| {
                                    if (std.mem.eql(u8, plain, resource)) {
                                        if (return_branch_fields) |sig_fields| {
                                            for (sig_fields) |sig_field| {
                                                if (sig_field.phantom) |phantom_str| {
                                                    var phantom = try phantom_parser.PhantomState.parse(self.allocator, phantom_str);
                                                    defer phantom.deinit(self.allocator);
                                                    switch (phantom) {
                                                        .concrete => |concrete| {
                                                            if (concrete.requires_cleanup) {
                                                                documented_escape = true;
                                                                log.debug("[CLEANUP]   '{s}' escapes through identity branch constructor with [!]\n", .{resource});
                                                            }
                                                        },
                                                        .variable => {},
                                                        .state_union => {},
                                                    }
                                                }
                                                break;
                                            }
                                        }
                                    }
                                } else {
                                    // Check each field in the constructor
                                    for (bc.fields) |bc_field| {
                                        // Check if this field's value matches the uncleaned resource
                                        if (bc_field.expression_str) |expr_str| {
                                            if (std.mem.eql(u8, expr_str, resource)) {
                                                // Found the resource being passed - check if output has [!]
                                                if (return_branch_fields) |sig_fields| {
                                                    for (sig_fields) |sig_field| {
                                                        if (std.mem.eql(u8, sig_field.name, bc_field.name)) {
                                                            if (sig_field.phantom) |phantom_str| {
                                                                var phantom = try phantom_parser.PhantomState.parse(self.allocator, phantom_str);
                                                                defer phantom.deinit(self.allocator);
                                                                switch (phantom) {
                                                                    .concrete => |concrete| {
                                                                        if (concrete.requires_cleanup) {
                                                                            documented_escape = true;
                                                                            log.debug("[CLEANUP]   '{s}' escapes through branch constructor field '{s}' with [!]\n", .{ resource, bc_field.name });
                                                                        }
                                                                    },
                                                                    .variable => {},
                                                                    .state_union => {},
                                                                }
                                                            }
                                                            break;
                                                        }
                                                    }
                                                }
                                                if (documented_escape) break;
                                            }
                                        }
                                    }
                                }
                            }
                        } else {
                            // Non-branch-constructor case: use the old field name matching
                            const fields_to_check = if (branch_payload) |bp| bp.fields else null;
                            if (fields_to_check) |fields| {
                                for (fields) |field| {
                                    if (field.phantom) |phantom_str| {
                                        var phantom = try phantom_parser.PhantomState.parse(self.allocator, phantom_str);
                                        defer phantom.deinit(self.allocator);
                                        switch (phantom) {
                                            .concrete => |concrete| {
                                                if (concrete.requires_cleanup) {
                                                    if (std.mem.lastIndexOf(u8, resource, ".")) |dot_idx| {
                                                        const resource_field = resource[dot_idx + 1 ..];
                                                        if (std.mem.eql(u8, resource_field, field.name)) {
                                                            documented_escape = true;
                                                            log.debug("[CLEANUP]   '{s}' escapes through signature field '{s}' with [!]\n", .{ resource, field.name });
                                                            break;
                                                        }
                                                    }
                                                }
                                            },
                                            .variable => {},
                                            .state_union => {},
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (!documented_escape) {
                        log.debug("[CLEANUP]   '{s}' NOT in signature - obligation lost\n", .{resource});
                        if (first_lost == null) {
                            first_lost = resource;
                        }
                        lost_count += 1;
                    }
                }

                // Only error if there are truly lost obligations (not documented in signature)
                if (lost_count > 0) {
                    log.debug("[CLEANUP] Lost obligations: {} - auto_discharge_inserter should have handled this\n", .{lost_count});

                    // Report error for each lost obligation
                    // (This is a safety net - inserter should have handled or errored)

                    // Use the same fields we used for detection
                    const fields_for_error = return_branch_fields orelse (if (branch_payload) |bp| bp.fields else null);

                    for (uncleaned) |resource| {
                        // Skip if it escapes through signature
                        var escapes = false;

                        // For hard terminals, nothing escapes
                        if (!is_hard_terminal) {
                            // For branch_constructor, check VALUE match (same as detection above)
                            if (is_branch_constructor) {
                                if (cont.node) |node| {
                                    const bc = &node.branch_constructor;
                                    // Identity branch constructors use plain_value
                                    if (bc.plain_value) |plain| {
                                        if (std.mem.eql(u8, plain, resource)) {
                                            if (return_branch_fields) |sig_fields| {
                                                for (sig_fields) |sig_field| {
                                                    if (sig_field.phantom) |phantom_str| {
                                                        var phantom = try phantom_parser.PhantomState.parse(self.allocator, phantom_str);
                                                        defer phantom.deinit(self.allocator);
                                                        switch (phantom) {
                                                            .concrete => |concrete| {
                                                                if (concrete.requires_cleanup) {
                                                                    escapes = true;
                                                                }
                                                            },
                                                            .variable => {},
                                                            .state_union => {},
                                                        }
                                                    }
                                                    break;
                                                }
                                            }
                                        }
                                    } else {
                                        for (bc.fields) |bc_field| {
                                            if (bc_field.expression_str) |expr_str| {
                                                if (std.mem.eql(u8, expr_str, resource)) {
                                                    if (return_branch_fields) |sig_fields| {
                                                        for (sig_fields) |sig_field| {
                                                            if (std.mem.eql(u8, sig_field.name, bc_field.name)) {
                                                                if (sig_field.phantom) |phantom_str| {
                                                                    var phantom = try phantom_parser.PhantomState.parse(self.allocator, phantom_str);
                                                                    defer phantom.deinit(self.allocator);
                                                                    switch (phantom) {
                                                                        .concrete => |concrete| {
                                                                            if (concrete.requires_cleanup) {
                                                                                escapes = true;
                                                                            }
                                                                        },
                                                                        .variable => {},
                                                                        .state_union => {},
                                                                    }
                                                                }
                                                                break;
                                                            }
                                                        }
                                                    }
                                                    if (escapes) break;
                                                }
                                            }
                                        }
                                    }
                                }
                            } else {
                                if (fields_for_error) |fields| {
                                    for (fields) |field| {
                                        if (field.phantom) |phantom_str| {
                                            var phantom = try phantom_parser.PhantomState.parse(self.allocator, phantom_str);
                                            defer phantom.deinit(self.allocator);
                                            switch (phantom) {
                                                .concrete => |concrete| {
                                                    if (concrete.requires_cleanup) {
                                                        if (std.mem.lastIndexOf(u8, resource, ".")) |dot_idx| {
                                                            if (std.mem.eql(u8, resource[dot_idx + 1 ..], field.name)) {
                                                                escapes = true;
                                                                break;
                                                            }
                                                        }
                                                    }
                                                },
                                                .variable => {},
                                                .state_union => {},
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        if (escapes) continue;

                        // Get the phantom state for this resource
                        const phantom_state = context.get(resource) orelse {
                            log.debug("[CLEANUP] No phantom state found for '{s}'\n", .{resource});
                            continue;
                        };

                        // Report error - obligation was not satisfied
                        // Format names for display - extract field name from paths like "_.conn"
                        const display_name = if (std.mem.indexOf(u8, resource, ".")) |dot_idx|
                            resource[dot_idx + 1 ..]
                        else
                            resource;
                        const display_state = if (std.mem.lastIndexOf(u8, phantom_state, ":")) |colon_idx|
                            phantom_state[colon_idx + 1 ..]
                        else
                            phantom_state;

                        // Find events that could discharge this obligation
                        var disposal_events = try self.findDisposalEventsForState(phantom_state);
                        defer {
                            for (disposal_events.items) |item| {
                                self.allocator.free(item);
                            }
                            disposal_events.deinit(self.allocator);
                        }

                        if (disposal_events.items.len == 0) {
                            // Strip ! suffix from display_state for the [!state] suggestion
                            const state_without_bang = if (std.mem.endsWith(u8, display_state, "!"))
                                display_state[0 .. display_state.len - 1]
                            else
                                display_state;
                            try self.reporter.addError(
                                .KORU030,
                                location.line,
                                location.column,
                                "Resource '{s}' [{s}] was not discharged. No event accepts [!{s}].",
                                .{ display_name, display_state, state_without_bang },
                            );
                        } else if (disposal_events.items.len == 1) {
                            try self.reporter.addError(
                                .KORU030,
                                location.line,
                                location.column,
                                "Resource '{s}' [{s}] was not discharged. Call: {s}",
                                .{ display_name, display_state, disposal_events.items[0] },
                            );
                        } else {
                            // Build comma-separated list of disposal options
                            var options_buf: [512]u8 = undefined;
                            var fbs = std.io.fixedBufferStream(&options_buf);
                            for (disposal_events.items, 0..) |event_name, i| {
                                if (i > 0) fbs.writer().writeAll(", ") catch {};
                                fbs.writer().writeAll(event_name) catch {};
                            }
                            try self.reporter.addError(
                                .KORU030,
                                location.line,
                                location.column,
                                "Resource '{s}' [{s}] was not discharged. Call one of: {s}",
                                .{ display_name, display_state, fbs.getWritten() },
                            );
                        }
                        has_errors = true;
                    }
                } else {
                    log.debug("[CLEANUP] ✓ All obligations either cleaned or documented in signature\n", .{});
                }
            } else {
                log.debug("[CLEANUP] ✓ No uncleaned resources at terminator\n", .{});
            }
        }

        // Validate nested continuations
        // Nested continuations belong to the LAST invocation in the pipeline, not the parent event
        if (cont.continuations.len > 0) {
            // Check if the single step is an invocation (or contains one)
            var last_invocation: ?*const ast.Invocation = null;
            if (cont.node) |step| {
                switch (step) {
                    .invocation => |*inv| {
                        last_invocation = inv;
                    },
                    .label_with_invocation => |*lwi| {
                        // Labels wrap invocations - extract the inner invocation
                        last_invocation = &lwi.invocation;
                    },
                    else => {},
                }
            }

            if (last_invocation) |inv| {
                // Look up the event invoked by the last step
                const event_name = try self.pathToString(inv.path);
                defer self.allocator.free(event_name);

                const module_name = inv.path.module_qualifier orelse flow_module;
                const qualified_name = try std.fmt.allocPrint(self.allocator, "{s}:{s}", .{ module_name, event_name });
                defer self.allocator.free(qualified_name);

                log.debug("[PHANTOM-FLOW]   Nested continuations belong to last invocation: '{s}'\n", .{qualified_name});

                const nested_event_info = event_map.get(qualified_name) orelse {
                    log.debug("[PHANTOM-FLOW]   Event '{s}' not found, skipping nested continuations\n", .{qualified_name});
                    return !has_errors;
                };

                // Validate nested continuations against the invoked event (not parent event)
                // Pass the current context down so disposed bindings propagate
                for (cont.continuations) |*nested| {
                    const nested_valid = try self.validateContinuation(nested, nested_event_info.decl, module_name, flow_module, event_map, location, &context, implementing_event);
                    if (!nested_valid) {
                        has_errors = true;
                        // Continue checking for more errors
                    }
                }
            } else {
                // Check if step is inline_code (from comptime transforms like print.ln)
                // inline_code represents void completions - nested continuations should be allowed
                var is_inline_code = false;
                if (cont.node) |step| {
                    if (step == .inline_code) {
                        is_inline_code = true;
                    }
                }

                if (is_inline_code) {
                    // inline_code is a void completion (e.g., from print.ln transform)
                    // Nested continuations should be validated as void event chain
                    // validateContinuationAsVoidChain handles invocation steps correctly -
                    // it looks up the event and validates nested branches against it
                    log.debug("[PHANTOM-FLOW]   Step is inline_code (void completion), validating nested continuations as void event chain\n", .{});
                    for (cont.continuations) |*nested| {
                        const nested_valid = try self.validateContinuationAsVoidChain(nested, flow_module, event_map, location, &context, implementing_event);
                        if (!nested_valid) {
                            has_errors = true;
                        }
                    }
                } else {
                    // No invocations in pipeline - nested continuations still belong to parent event
                    log.debug("[PHANTOM-FLOW]   No invocations in pipeline, nested continuations belong to parent event\n", .{});
                    for (cont.continuations) |*nested| {
                        const nested_valid = try self.validateContinuation(nested, event_decl, event_module, flow_module, event_map, location, &context, implementing_event);
                        if (!nested_valid) {
                            has_errors = true;
                            // Continue checking for more errors
                        }
                    }
                }
            }
        }

        return !has_errors;
    }

    /// Validate a continuation as part of a void event chain (e.g., after inline_code)
    /// This allows empty-branch continuations without checking against a parent event's branches
    fn validateContinuationAsVoidChain(
        self: *PhantomSemanticChecker,
        cont: *const ast.Continuation,
        flow_module: ?[]const u8,
        event_map: *std.StringHashMap(EventInfo),
        location: errors.SourceLocation,
        parent_context: ?*const BindingContext,
        implementing_event: ?*const ast.EventDecl,
    ) anyerror!bool {
        var has_errors = false;

        log.debug("[PHANTOM-FLOW]   Void chain continuation, branch: '{s}'\n", .{cont.branch});

        // Create context for this continuation
        var context = if (parent_context) |parent|
            try BindingContext.inherit(parent, self.allocator)
        else
            BindingContext.init(self.allocator);
        defer context.deinit();

        // Empty branch is valid in void chains
        if (cont.branch.len == 0) {
            // Validate the step if present
            if (cont.node) |*step| {
                const step_valid = try self.validateStep(step, &context, event_map, flow_module, location);
                if (!step_valid) {
                    has_errors = true;
                }

                // Check if step is an invocation - if so, nested continuations belong to that event
                switch (step.*) {
                    .invocation => |*inv| {
                        // Look up the event
                        const event_name = try self.pathToString(inv.path);
                        defer self.allocator.free(event_name);
                        const resolved_module = inv.path.module_qualifier orelse flow_module orelse "unknown";
                        const qualified_name = try std.fmt.allocPrint(self.allocator, "{s}:{s}", .{ resolved_module, event_name });
                        defer self.allocator.free(qualified_name);

                        if (event_map.get(qualified_name)) |event_info| {
                            // Validate nested continuations against this event
                            for (cont.continuations) |*nested| {
                                const nested_valid = try self.validateContinuation(nested, event_info.decl, resolved_module, flow_module orelse "unknown", event_map, location, &context, implementing_event);
                                if (!nested_valid) {
                                    has_errors = true;
                                }
                            }
                            return !has_errors;
                        }
                    },
                    .inline_code => {
                        // Another inline_code - recursively validate as void chain
                        for (cont.continuations) |*nested| {
                            const nested_valid = try self.validateContinuationAsVoidChain(nested, flow_module, event_map, location, &context, implementing_event);
                            if (!nested_valid) {
                                has_errors = true;
                            }
                        }
                        return !has_errors;
                    },
                    else => {},
                }
            }

            // No step or unknown step type - recursively validate nested as void chain
            for (cont.continuations) |*nested| {
                const nested_valid = try self.validateContinuationAsVoidChain(nested, flow_module, event_map, location, &context, implementing_event);
                if (!nested_valid) {
                    has_errors = true;
                }
            }
        } else {
            // Non-empty branch in void chain is an error
            try self.reporter.addError(.KORU030, location.line, location.column, "Continuation expects branch '{s}' but void event chain has no branches", .{cont.branch});
            has_errors = true;
        }

        return !has_errors;
    }

    fn validateStep(self: *PhantomSemanticChecker, step: *const ast.Step, context: *BindingContext, event_map: *std.StringHashMap(EventInfo), current_module: ?[]const u8, location: errors.SourceLocation) !bool {
        var has_errors = false;
        log.debug("[PHANTOM-FLOW] Validating step: {s}\n", .{@tagName(step.*)});

        switch (step.*) {
            .invocation => |inv| {
                return self.validateSingleInvocation(&inv, context, event_map, current_module, location);
            },
            .label_with_invocation => |lwi| {
                // If it's a declaration (#loop), mark parent obligations as outer scope
                // so that @loop() jumps don't flag them as dropped.
                if (lwi.is_declaration) {
                    var scoped_context = try BindingContext.inheritWithScope(context, self.allocator);
                    defer scoped_context.deinit();
                    return self.validateSingleInvocation(&lwi.invocation, &scoped_context, event_map, current_module, location);
                } else {
                    // It's a jump without semantic args (legacy)
                    return true;
                }
            },
            .label_jump => |lj| {
                // Look up the target event for this label
                const target_decl = self.label_map.get(lj.label);
                if (target_decl) |decl| {
                    // Validate jump arguments against target event's signature
                    for (lj.args) |arg| {
                        const arg_valid = try self.validateArgument(arg, decl, decl.module, context, location);
                        if (!arg_valid) {
                            has_errors = true;
                        }
                    }

                    // Validate event-level phantom preconditions for the jump
                    const context_valid = try self.validateEventContextPhantom(decl, decl.module, context, location, lj.label);
                    if (!context_valid) has_errors = true;
                } else {
                    log.debug("[PHANTOM-FLOW]   Label '@{s}' not found in map, skipping jump arg validation\n", .{lj.label});
                }

                // Label jumps must not drop cleanup obligations.
                // Exception: jumps to declared labels (#loop) are backward jumps that
                // preserve the enclosing scope — obligations survive across iterations.
                const is_loop_jump = self.label_map.contains(lj.label);
                if (!is_loop_jump and context.hasUncleanedResources()) {
                    const uncleaned = try context.getUncleanedResources(self.allocator);
                    defer self.allocator.free(uncleaned);

                    for (uncleaned) |resource| {
                        if (context.isOuterScope(resource)) {
                            continue;
                        }
                        var passed = false;
                        for (lj.args) |arg| {
                            if (std.mem.eql(u8, arg.value, resource)) {
                                passed = true;
                                break;
                            }
                        }
                        if (!passed) {
                            try self.reporter.addError(.KORU030, location.line, location.column, "Label jump '@{s}' drops cleanup obligation for '{s}' - pass it as an argument or discharge it before jumping", .{ lj.label, resource });
                            has_errors = true;
                        }
                    }
                }

                return !has_errors;
            },
            .conditional_block => |cb| {
                for (cb.nodes) |*s| {
                    const inner_valid = try self.validateStep(s, context, event_map, current_module, location);
                    if (!inner_valid) has_errors = true;
                }
                return !has_errors;
            },
            .foreach => |fe| {
                log.debug("[PHANTOM-FLOW] Validating foreach with {} branches\n", .{fe.branches.len});
                for (fe.branches) |*branch| {
                    const branch_valid = try self.validateNamedBranchRecursive(branch, context, event_map, current_module, location);
                    if (!branch_valid) has_errors = true;
                }
                return !has_errors;
            },
            .conditional => |cond| {
                log.debug("[PHANTOM-FLOW] Validating conditional with {} branches\n", .{cond.branches.len});
                for (cond.branches) |*branch| {
                    const branch_valid = try self.validateNamedBranchRecursive(branch, context, event_map, current_module, location);
                    if (!branch_valid) has_errors = true;
                }
                return !has_errors;
            },
            .switch_result => |sr| {
                log.debug("[PHANTOM-FLOW] Validating switch_result with {} branches\n", .{sr.branches.len});
                for (sr.branches) |*branch| {
                    const branch_valid = try self.validateNamedBranchRecursive(branch, context, event_map, current_module, location);
                    if (!branch_valid) has_errors = true;
                }
                return !has_errors;
            },
            .branch_constructor => |bc| {
                // Validate phantom states in inline branch construction
                for (bc.fields) |field| {
                    if (field.phantom) |phantom_str| {
                        _ = phantom_str; // TODO: Validate that the provided value matches the phantom annotation
                    }
                }
                return true;
            },
            else => {
                // Other step types don't involve phantom states
                return true;
            },
        }
    }

    /// Validate a NamedBranch (from foreach or conditional)
    /// Handles @scope annotations to track outer-scope obligations
    /// This function does NOT call validateStep to avoid mutual recursion
    fn validateNamedBranchRecursive(self: *PhantomSemanticChecker, branch: *const ast.NamedBranch, parent_context: *BindingContext, event_map: *std.StringHashMap(EventInfo), current_module: ?[]const u8, location: errors.SourceLocation) !bool {
        var has_errors = false;

        // Check if this branch has @scope annotation
        const has_scope = blk: {
            for (branch.annotations) |ann| {
                if (std.mem.eql(u8, ann, "@scope")) {
                    break :blk true;
                }
            }
            break :blk false;
        };

        log.debug("[PHANTOM-FLOW] Validating branch '{s}' (has_scope={}, {} continuations)\n", .{ branch.name, has_scope, branch.body.len });

        // Create context for this branch
        // If @scope, use inheritWithScope to mark existing obligations as outer-scope
        var branch_context = if (has_scope)
            try BindingContext.inheritWithScope(parent_context, self.allocator)
        else
            try BindingContext.inherit(parent_context, self.allocator);
        defer branch_context.deinit();

        // Validate each continuation in the branch body
        for (branch.body) |*cont| {
            // NOTE: We do NOT check outer-scope obligations at terminators inside @scope.
            // Outer obligations are "suspended" - they'll be checked when the OUTER scope
            // terminates (e.g., in the `done` branch after a for-loop).
            // The auto_discharge_inserter handles the actual disposal logic, respecting @scope.

            // Validate the step if present - handle recursively for nested structures
            if (cont.node) |step| {
                switch (step) {
                    .foreach => |fe| {
                        for (fe.branches) |*inner_branch| {
                            const valid = try self.validateNamedBranchRecursive(inner_branch, &branch_context, event_map, current_module, location);
                            if (!valid) has_errors = true;
                        }
                    },
                    .conditional => |cond| {
                        for (cond.branches) |*inner_branch| {
                            const valid = try self.validateNamedBranchRecursive(inner_branch, &branch_context, event_map, current_module, location);
                            if (!valid) has_errors = true;
                        }
                    },
                    .switch_result => |sr| {
                        for (sr.branches) |*inner_branch| {
                            const valid = try self.validateNamedBranchRecursive(inner_branch, &branch_context, event_map, current_module, location);
                            if (!valid) has_errors = true;
                        }
                    },
                    .invocation => |inv| {
                        const valid = try self.validateSingleInvocation(&inv, &branch_context, event_map, current_module, location);
                        if (!valid) has_errors = true;
                    },
                    else => {
                        // Other step types (terminal, inline_code, etc.) don't need recursive validation
                    },
                }
            }

            // Resolve the event whose branches the nested continuations represent.
            // Nested continuations of `cont` are branches of cont.node when cont.node is
            // an invocation. validateContinuation needs the event_decl to add the
            // continuation's binding to the context with the correct phantom state.
            var nested_event_decl: ?*const ast.EventDecl = null;
            var nested_event_module: ?[]const u8 = null;
            if (cont.node) |step_for_nested| switch (step_for_nested) {
                .invocation => |inv_for_nested| {
                    const ev_name = try self.pathToString(inv_for_nested.path);
                    defer self.allocator.free(ev_name);
                    nested_event_module = inv_for_nested.path.module_qualifier orelse current_module;
                    const qualified = if (nested_event_module) |m|
                        try std.fmt.allocPrint(self.allocator, "{s}:{s}", .{ m, ev_name })
                    else
                        try self.allocator.dupe(u8, ev_name);
                    defer self.allocator.free(qualified);
                    if (event_map.get(qualified)) |info| nested_event_decl = info.decl;
                },
                else => {},
            };

            // Recursively validate nested continuations
            for (cont.continuations) |*nested| {
                // NOTE: We do NOT check outer-scope obligations at terminators inside @scope.
                // Outer obligations are "suspended" - they'll be checked when the outer scope
                // terminates. The auto_discharge_inserter handles disposal, respecting @scope.

                // If we know the parent invocation's event, route through validateContinuation
                // so the binding (e.g. identity capture from `| opened f |>`) gets registered
                // before the inner step is validated. Without this, synthesized disposal calls
                // referencing those bindings see an empty context and fail.
                if (nested_event_decl) |ev_decl| {
                    const valid = try self.validateContinuation(
                        nested,
                        ev_decl,
                        nested_event_module,
                        current_module orelse "",
                        event_map,
                        location,
                        &branch_context,
                        null,
                    );
                    if (!valid) has_errors = true;
                    continue;
                }

                // Fallback: parent step isn't an invocation we can resolve. Validate
                // recursively for nested structures (best effort, no binding tracking).
                if (nested.node) |step| {
                    switch (step) {
                        .foreach => |fe| {
                            for (fe.branches) |*inner_branch| {
                                const valid = try self.validateNamedBranchRecursive(inner_branch, &branch_context, event_map, current_module, location);
                                if (!valid) has_errors = true;
                            }
                        },
                        .conditional => |cond| {
                            for (cond.branches) |*inner_branch| {
                                const valid = try self.validateNamedBranchRecursive(inner_branch, &branch_context, event_map, current_module, location);
                                if (!valid) has_errors = true;
                            }
                        },
                        .switch_result => |sr| {
                            for (sr.branches) |*inner_branch| {
                                const valid = try self.validateNamedBranchRecursive(inner_branch, &branch_context, event_map, current_module, location);
                                if (!valid) has_errors = true;
                            }
                        },
                        .invocation => |inv| {
                            const valid = try self.validateSingleInvocation(&inv, &branch_context, event_map, current_module, location);
                            if (!valid) has_errors = true;
                        },
                        else => {},
                    }
                }
            }
        }

        return !has_errors;
    }

    fn validateSingleInvocation(self: *PhantomSemanticChecker, inv: *const ast.Invocation, context: *BindingContext, event_map: *std.StringHashMap(EventInfo), current_module: ?[]const u8, location: errors.SourceLocation) !bool {
        var has_errors = false;
        // Get the event name from path segments
        const event_name = try self.pathToString(inv.path);
        defer self.allocator.free(event_name);

        // Determine the module - use module_qualifier if present, otherwise current_module
        const module_name = inv.path.module_qualifier orelse current_module;

        // Build fully-qualified event name (module:event)
        const qualified_name = if (module_name) |mod|
            try std.fmt.allocPrint(self.allocator, "{s}:{s}", .{ mod, event_name })
        else
            try self.allocator.dupe(u8, event_name);
        defer self.allocator.free(qualified_name);

        log.debug("[PHANTOM-FLOW]   Single invocation: '{s}' → qualified: '{s}'\n", .{ event_name, qualified_name });

        const event_info = event_map.get(qualified_name) orelse {
            log.debug("[PHANTOM-FLOW]   Event '{s}' not found in map, skipping step\n", .{qualified_name});
            return true;
        };

        // Validate each argument against event signature
        for (inv.args) |arg| {
            const arg_valid = try self.validateArgument(arg, event_info.decl, module_name, context, location);
            if (!arg_valid) {
                has_errors = true;
            }
        }

        // Validate event-level phantom preconditions
        const context_valid = try self.validateEventContextPhantom(event_info.decl, module_name, context, location, event_name);
        if (!context_valid) has_errors = true;

        return !has_errors;
    }

    fn validateEventContextPhantom(self: *PhantomSemanticChecker, event_decl: *const ast.EventDecl, event_module: ?[]const u8, context: *BindingContext, location: errors.SourceLocation, event_name: []const u8) !bool {
        var has_errors = false;
        log.debug("[PHANTOM-FLOW]   Checking event context phantoms for '{s}' ({} annotations)\n", .{ event_name, event_decl.annotations.len });
        for (event_decl.annotations, 0..) |ann, i| {
            log.debug("[PHANTOM-FLOW]     Annotation[{}]: '{s}' (isPhantom={})\n", .{ i, ann, isPhantomAnnotation(ann) });
            if (isPhantomAnnotation(ann)) {
                // Precondition found!
                const provided_state = context.get("") orelse "";
                log.debug("[PHANTOM-FLOW]     Precondition found: '{s}', current context: '{s}'\n", .{ ann, provided_state });

                const canonical_expected = try self.canonicalizePhantomState(ann, event_module orelse event_decl.module);
                defer self.allocator.free(canonical_expected);

                const provided_phantom = context.get("") orelse {
                    // Error: context-level phantom required but not provided
                    log.debug("[PHANTOM-FLOW] ❌ CONTEXT MISMATCH! Expected {s} but no context state defined\n", .{canonical_expected});
                    try self.reporter.addError(.KORU030, location.line, location.column, "Phantom state mismatch for event '{s}': expected context state '{s}' but no context state is defined", .{ event_name, canonical_expected });
                    has_errors = true;
                    continue;
                };

                const canonical_provided = try self.canonicalizePhantomState(provided_phantom, event_module orelse event_decl.module);
                defer self.allocator.free(canonical_provided);

                log.debug("[PHANTOM-FLOW] Comparing context phantoms: expected={s}, provided={s}\n", .{ canonical_expected, canonical_provided });

                const compatible = try phantom_parser.areCompatible(self.allocator, canonical_expected, canonical_provided);
                if (!compatible) {
                    log.debug("[PHANTOM-FLOW] ❌ CONTEXT MISMATCH!\n", .{});
                    try self.reporter.addError(.KORU030, location.line, location.column, "Phantom state mismatch for event '{s}': expected context state '{s}' but found '{s}'", .{ event_name, canonical_expected, canonical_provided });
                    has_errors = true;
                }
            }
        }
        return !has_errors;
    }

    fn isPhantomAnnotation(ann: []const u8) bool {
        // Simple heuristic: starts with Type[ or *Type[
        // In the future, this should be more robust or defined by a list of phantom types
        const has_open = std.mem.indexOf(u8, ann, "[") != null;
        const has_close = std.mem.endsWith(u8, ann, "]");
        return has_open and has_close;
    }

    fn validateArgument(
        self: *PhantomSemanticChecker,
        arg: ast.Arg,
        event_decl: *const ast.EventDecl,
        event_module: ?[]const u8, // Qualified module name from event lookup
        context: *BindingContext,
        location: errors.SourceLocation,
    ) !bool {
        // Find the field in event input - get both phantom AND base type
        var expected_phantom: ?[]const u8 = null;
        var expected_base_type_raw: ?[]const u8 = null;
        var expected_module_path: ?[]const u8 = null;
        for (event_decl.input.fields) |field| {
            if (std.mem.eql(u8, field.name, arg.name)) {
                expected_phantom = field.phantom;
                expected_base_type_raw = field.type;
                expected_module_path = field.module_path;
                break;
            }
        }

        if (expected_phantom == null) {
            // No phantom state expected for this field
            return true;
        }

        // Canonicalize expected base type
        const module_for_canon = event_module orelse event_decl.module;
        const expected_base_type = try self.canonicalizeBaseType(
            expected_base_type_raw.?,
            expected_module_path,
            module_for_canon,
        );
        defer self.allocator.free(expected_base_type);

        // Debug: print what we're looking for
        log.debug("[PHANTOM-FLOW] Checking arg '{s}' with value '{s}'\n", .{ arg.name, arg.value });
        log.debug("[PHANTOM-FLOW]   Expected type: '{s}[{s}]'\n", .{ expected_base_type, expected_phantom.? });

        // Check if the binding has been disposed
        if (context.isDisposed(arg.value)) {
            log.debug("[CLEANUP] ❌ USE AFTER DISPOSAL DETECTED!\n", .{});
            try self.reporter.addError(
                .KORU030,
                location.line,
                location.column,
                "Use-after-disposal: binding '{s}' was already disposed and cannot be used",
                .{arg.value},
            );
            return false;
        }

        // Get the full binding info (phantom state + base type) from context
        const binding_info = context.getInfo(arg.value) orelse {
            log.debug("[PHANTOM-FLOW]   No binding found for '{s}' in context\n", .{arg.value});
            // Value is not a tracked binding.
            // If the event REQUIRES a phantom state (expected_phantom is set),
            // then passing an untracked value is an error - we can't verify the state.
            // For example: query(conn: *Connection[connected]) requires the input to be
            // in [connected] state, but if we got *Connection (no phantom) from another
            // event, that's a type mismatch.
            //
            // HOWEVER: Earlier compiler passes (like auto-discharge) may rename bindings
            // (e.g., outermost_f -> _auto_2), so the argument value may not match
            // the original binding name in our context. For field accesses (containing .),
            // we can try to match by field name suffix since the field name is stable.
            //
            // If the argument looks like a field access and we find a matching field
            // name in the context, we should use that binding instead.
            if (std.mem.indexOf(u8, arg.value, ".")) |dot_idx| {
                const field_suffix = arg.value[dot_idx..]; // e.g., ".file"
                // Search for any binding ending with this field suffix
                var iter = context.bindings.iterator();
                while (iter.next()) |entry| {
                    if (std.mem.endsWith(u8, entry.key_ptr.*, field_suffix)) {
                        // Found a matching binding - use it
                        log.debug("[PHANTOM-FLOW]   Found binding by field suffix: '{s}' matches '{s}'\n", .{ entry.key_ptr.*, arg.value });
                        // Continue with validation using this binding
                        const matched_info = entry.value_ptr.*;
                        // Validate phantom state compatibility (same as below)
                        const canonical_expected = try self.canonicalizePhantomState(expected_phantom.?, module_for_canon);
                        defer self.allocator.free(canonical_expected);
                        const canonical_provided = try self.canonicalizePhantomState(matched_info.phantom_state, module_for_canon);
                        defer self.allocator.free(canonical_provided);

                        const compatible = try phantom_parser.areCompatible(self.allocator, canonical_expected, canonical_provided);
                        if (!compatible) {
                            try self.reporter.addError(
                                .KORU030,
                                location.line,
                                location.column,
                                "Phantom state mismatch: expected '{s}' but got '{s}' for argument '{s}'",
                                .{ canonical_expected, canonical_provided, arg.name },
                            );
                            return false;
                        }

                        // Check if this event consumes the obligation
                        var expected_phantom_parsed = try phantom_parser.PhantomState.parse(self.allocator, expected_phantom.?);
                        defer expected_phantom_parsed.deinit(self.allocator);
                        switch (expected_phantom_parsed) {
                            .concrete => |concrete| {
                                if (concrete.consumes_obligation) {
                                    // Find and clear the matched binding's obligation
                                    context.clearCleanupObligation(entry.key_ptr.*);
                                    try context.markDisposed(entry.key_ptr.*);
                                }
                            },
                            .variable => {},
                            .state_union => |u| {
                                var any_consumes = false;
                                for (u.members) |m| if (m.consumes_obligation) {
                                    any_consumes = true;
                                    break;
                                };
                                if (any_consumes) {
                                    context.clearCleanupObligation(entry.key_ptr.*);
                                    try context.markDisposed(entry.key_ptr.*);
                                }
                            },
                        }
                        return true;
                    }
                }
            }

            // No matching binding found - this is an error if phantom state is required
            // Parse expected_phantom to check what kind of requirement it is:
            // - [state] (no !) = requirement - the value MUST be in this state
            // - [!state] (prefix !) = consumption - consumes an existing obligation
            // Both cases require the binding to be tracked with the correct state.
            var expected_parsed = try phantom_parser.PhantomState.parse(self.allocator, expected_phantom.?);
            defer expected_parsed.deinit(self.allocator);

            switch (expected_parsed) {
                .concrete => |concrete| {
                    // Whether it's a requirement or consumption, we need the binding tracked
                    const canonical_expected = try self.canonicalizePhantomState(expected_phantom.?, module_for_canon);
                    defer self.allocator.free(canonical_expected);

                    if (concrete.consumes_obligation) {
                        // [!state] - consumption - argument must have an obligation to consume
                        try self.reporter.addError(
                            .KORU030,
                            location.line,
                            location.column,
                            "Phantom state mismatch: argument '{s}' has no tracked phantom state, but event requires '[!{s}]' (consumption). Did you mean to pass a value with state '{s}'?",
                            .{ arg.name, concrete.name, canonical_expected },
                        );
                    } else {
                        // [state] - requirement - argument must be in this state
                        try self.reporter.addError(
                            .KORU030,
                            location.line,
                            location.column,
                            "Phantom state mismatch: argument '{s}' has no tracked phantom state, but event requires '[{s}]'. The value must be in state '{s}'.",
                            .{ arg.name, expected_phantom.?, canonical_expected },
                        );
                    }
                    return false;
                },
                .variable => {
                    // State variable - the event is polymorphic, any state is fine
                    // (or no state - the variable will be bound at the call site)
                    return true;
                },
                .state_union => {
                    // State union - the event accepts multiple states
                    // If the binding isn't tracked, we can't verify it's in one of those states
                    try self.reporter.addError(
                        .KORU030,
                        location.line,
                        location.column,
                        "Phantom state mismatch: argument '{s}' has no tracked phantom state, but event requires one of '[{s}]'.",
                        .{ arg.name, expected_phantom.? },
                    );
                    return false;
                },
            }
        };

        const provided_phantom = binding_info.phantom_state;
        const provided_base_type = binding_info.base_type;

        log.debug("[PHANTOM-FLOW]   Provided type: '{s}[{s}]'\n", .{ provided_base_type, provided_phantom });

        // Base type checking (when --strict-base-types flag is set)
        // Without this flag, we rely on Zig's type system to catch mismatches lazily,
        // which is more accurate than our string-based comparison (handles type aliases, etc.)
        // With this flag, we check eagerly but may have false positives/negatives.
        if (comptime CompilerEnv.hasFlag("strict-base-types")) {
            if (provided_base_type.len > 0 and !std.mem.eql(u8, expected_base_type, provided_base_type)) {
                log.debug("[PHANTOM-FLOW] ❌ BASE TYPE MISMATCH!\n", .{});
                try self.reporter.addError(
                    .KORU030,
                    location.line,
                    location.column,
                    "Type mismatch: expected '{s}[{s}]' but got '{s}[{s}]' for argument '{s}'",
                    .{ expected_base_type, expected_phantom.?, provided_base_type, provided_phantom, arg.name },
                );
                return false;
            }
        }

        // Canonicalize both phantom states for proper comparison
        // Use event_module (qualified module name from lookup) for proper canonicalization
        const canonical_expected = try self.canonicalizePhantomState(
            expected_phantom.?,
            module_for_canon,
        );
        defer self.allocator.free(canonical_expected);

        // Provided phantom is already qualified, but might not be canonical - canonicalize it too
        // We need to parse it to get its module, then resolve through module_map
        const canonical_provided = try self.canonicalizePhantomState(
            provided_phantom,
            module_for_canon, // Use event's qualified module as fallback if provided has no module
        );
        defer self.allocator.free(canonical_provided);

        log.debug("[PHANTOM-FLOW]   Canonical expected: '{s}'\n", .{canonical_expected});
        log.debug("[PHANTOM-FLOW]   Canonical provided: '{s}'\n", .{canonical_provided});

        // Check compatibility using canonicalized phantom states
        const compatible = try phantom_parser.areCompatible(
            self.allocator,
            canonical_expected,
            canonical_provided,
        );

        if (!compatible) {
            log.debug("[PHANTOM-FLOW] ❌ PHANTOM STATE MISMATCH!\n", .{});
            try self.reporter.addError(
                .KORU030,
                location.line,
                location.column,
                "Phantom state mismatch: expected '{s}' but got '{s}' for argument '{s}'",
                .{ canonical_expected, canonical_provided, arg.name },
            );
            // Return false to indicate error, but don't stop checking
            return false;
        }

        log.debug("[PHANTOM-FLOW]   ✓ Type and phantom state compatible\n", .{});

        // Check if this event consumes the obligation (marked with ! prefix)
        var expected_phantom_parsed = try phantom_parser.PhantomState.parse(self.allocator, expected_phantom.?);
        defer expected_phantom_parsed.deinit(self.allocator);

        switch (expected_phantom_parsed) {
            .concrete => |concrete| {
                if (concrete.consumes_obligation) {
                    log.debug("[CLEANUP] Event parameter has [!{s}] - consumes obligation\n", .{concrete.name});
                    // This event disposes the resource - clear the cleanup obligation
                    context.clearCleanupObligation(arg.value);
                    // Mark the binding as disposed (poisoned - cannot be used anymore)
                    try context.markDisposed(arg.value);
                }
            },
            .variable => {},
            .state_union => |u| {
                var any_consumes = false;
                for (u.members) |m| if (m.consumes_obligation) {
                    any_consumes = true;
                    break;
                };
                if (any_consumes) {
                    log.debug("[CLEANUP] Event parameter has union member with [!] - consumes obligation\n", .{});
                    context.clearCleanupObligation(arg.value);
                    try context.markDisposed(arg.value);
                }
            },
        }

        return true;
    }

    /// Qualify a local phantom state with a module name
    /// - "open" + "mipmap" → "mipmap:open"
    /// - "fs:open" + "mipmap" → "fs:open" (already qualified, unchanged)
    /// - "M'_" + "mipmap" → "M'_" (state variable, unchanged)
    /// - "open" + null → "open" (no module, unchanged)
    fn qualifyPhantomState(self: *PhantomSemanticChecker, phantom_str: []const u8, module_name: ?[]const u8) ![]const u8 {
        // No module name? Return unchanged
        if (module_name == null) return phantom_str;

        // Parse to check if it's already qualified or is a state variable
        var phantom = try phantom_parser.PhantomState.parse(self.allocator, phantom_str);
        defer phantom.deinit(self.allocator);

        switch (phantom) {
            .concrete => |concrete| {
                // Already module-qualified? Return unchanged
                if (concrete.module_path != null) {
                    return phantom_str;
                }

                // Local state - qualify it with module name
                return try std.fmt.allocPrint(self.allocator, "{s}:{s}", .{ module_name.?, concrete.name });
            },
            .variable => {
                // State variables are not qualified with modules
                return phantom_str;
            },
            .state_union => {
                // State unions are not qualified - they may have mixed modules
                return phantom_str;
            },
        }
    }

    fn pathToString(self: *PhantomSemanticChecker, path: ast.DottedPath) ![]const u8 {
        if (path.segments.len == 0) return try self.allocator.dupe(u8, "");
        if (path.segments.len == 1) return try self.allocator.dupe(u8, path.segments[0]);

        // Calculate total length
        var total_len: usize = path.segments[0].len;
        for (path.segments[1..]) |seg| {
            total_len += 1 + seg.len; // dot + segment
        }

        // Build string
        var result = try self.allocator.alloc(u8, total_len);
        var pos: usize = 0;

        @memcpy(result[pos .. pos + path.segments[0].len], path.segments[0]);
        pos += path.segments[0].len;

        for (path.segments[1..]) |seg| {
            result[pos] = '.';
            pos += 1;
            @memcpy(result[pos .. pos + seg.len], seg);
            pos += seg.len;
        }

        return result;
    }
};

// ============================================================================
// Unit Tests for BindingContext
// ============================================================================
// These tests verify the core obligation tracking logic that powers Koru's
// phantom type system. BindingContext tracks:
// - Variable bindings and their phantom states
// - Cleanup obligations (resources with ! suffix that must be disposed)
// - Disposed bindings (poisoned - cannot be reused after disposal)
// - Scope boundaries (@scope annotation handling)

// Use full path to avoid ambiguity with internal declaration
const TestBindingContext = PhantomSemanticChecker.BindingContext;

test "BindingContext - basic set and get" {
    const allocator = std.testing.allocator;
    var ctx = TestBindingContext.init(allocator);
    defer ctx.deinit();

    // Set a binding without obligation
    try ctx.set("file", "open");

    // Get should return the value
    const value = ctx.get("file");
    try std.testing.expect(value != null);
    try std.testing.expectEqualStrings("open", value.?);

    // Unknown binding returns null
    try std.testing.expect(ctx.get("unknown") == null);
}

test "BindingContext - overwrite binding" {
    const allocator = std.testing.allocator;
    var ctx = TestBindingContext.init(allocator);
    defer ctx.deinit();

    try ctx.set("file", "open");
    try ctx.set("file", "closed"); // Overwrite

    const value = ctx.get("file");
    try std.testing.expectEqualStrings("closed", value.?);
}

test "BindingContext - cleanup obligation tracking with ! suffix" {
    const allocator = std.testing.allocator;
    var ctx = TestBindingContext.init(allocator);
    defer ctx.deinit();

    // State WITHOUT obligation marker
    try ctx.set("safe_file", "closed");
    try std.testing.expect(!ctx.hasUncleanedResources());

    // State WITH obligation marker (! suffix)
    try ctx.set("risky_file", "opened!");
    try std.testing.expect(ctx.hasUncleanedResources());

    // Verify the obligation is tracked
    const uncleaned = try ctx.getUncleanedResources(allocator);
    defer allocator.free(uncleaned);
    try std.testing.expectEqual(@as(usize, 1), uncleaned.len);
    try std.testing.expectEqualStrings("risky_file", uncleaned[0]);
}

test "BindingContext - module-qualified obligation tracking" {
    const allocator = std.testing.allocator;
    var ctx = TestBindingContext.init(allocator);
    defer ctx.deinit();

    // Module-qualified state with obligation
    try ctx.set("handle", "fs:opened!");
    try std.testing.expect(ctx.hasUncleanedResources());

    const uncleaned = try ctx.getUncleanedResources(allocator);
    defer allocator.free(uncleaned);
    try std.testing.expectEqual(@as(usize, 1), uncleaned.len);
}

test "BindingContext - clear cleanup obligation" {
    const allocator = std.testing.allocator;
    var ctx = TestBindingContext.init(allocator);
    defer ctx.deinit();

    try ctx.set("file", "opened!");
    try std.testing.expect(ctx.hasUncleanedResources());

    // Clear the obligation (simulating disposal)
    ctx.clearCleanupObligation("file");
    try std.testing.expect(!ctx.hasUncleanedResources());
}

test "BindingContext - disposal poisoning" {
    const allocator = std.testing.allocator;
    var ctx = TestBindingContext.init(allocator);
    defer ctx.deinit();

    try ctx.set("file", "opened!");

    // Not disposed yet
    try std.testing.expect(!ctx.isDisposed("file"));

    // Mark as disposed
    try ctx.markDisposed("file");

    // Now it's poisoned
    try std.testing.expect(ctx.isDisposed("file"));

    // Unknown bindings are not disposed
    try std.testing.expect(!ctx.isDisposed("other"));
}

test "BindingContext - multiple obligations" {
    const allocator = std.testing.allocator;
    var ctx = TestBindingContext.init(allocator);
    defer ctx.deinit();

    try ctx.set("file1", "opened!");
    try ctx.set("file2", "opened!");
    try ctx.set("file3", "closed"); // No obligation

    try std.testing.expect(ctx.hasUncleanedResources());

    const uncleaned = try ctx.getUncleanedResources(allocator);
    defer allocator.free(uncleaned);
    try std.testing.expectEqual(@as(usize, 2), uncleaned.len);

    // Clear one
    ctx.clearCleanupObligation("file1");

    const remaining = try ctx.getUncleanedResources(allocator);
    defer allocator.free(remaining);
    try std.testing.expectEqual(@as(usize, 1), remaining.len);
}

test "BindingContext - inherit from parent" {
    const allocator = std.testing.allocator;

    // Create parent context
    var parent = TestBindingContext.init(allocator);
    defer parent.deinit();

    try parent.set("inherited_file", "opened!");
    try parent.set("safe_data", "valid");

    // Create child that inherits
    var child = try TestBindingContext.inherit(&parent, allocator);
    defer child.deinit();

    // Child should see parent's bindings
    try std.testing.expectEqualStrings("opened!", child.get("inherited_file").?);
    try std.testing.expectEqualStrings("valid", child.get("safe_data").?);

    // Child inherits cleanup obligations
    try std.testing.expect(child.hasUncleanedResources());

    // Child modifications don't affect parent
    try child.set("child_only", "new!");
    try std.testing.expect(parent.get("child_only") == null);
}

test "BindingContext - inherit disposed state" {
    const allocator = std.testing.allocator;

    var parent = TestBindingContext.init(allocator);
    defer parent.deinit();

    try parent.set("file", "opened!");
    try parent.markDisposed("file");

    var child = try TestBindingContext.inherit(&parent, allocator);
    defer child.deinit();

    // Child inherits disposed state - file is poisoned
    try std.testing.expect(child.isDisposed("file"));
}

test "BindingContext - inheritWithScope marks obligations as outer" {
    const allocator = std.testing.allocator;

    var parent = TestBindingContext.init(allocator);
    defer parent.deinit();

    try parent.set("outer_file", "opened!");

    // Create child with @scope boundary
    var scoped_child = try TestBindingContext.inheritWithScope(&parent, allocator);
    defer scoped_child.deinit();

    // Child sees the binding
    try std.testing.expectEqualStrings("opened!", scoped_child.get("outer_file").?);

    // Child has the obligation
    try std.testing.expect(scoped_child.hasUncleanedResources());

    // But it's marked as outer scope!
    try std.testing.expect(scoped_child.isOuterScope("outer_file"));
    try std.testing.expect(scoped_child.hasOuterScopeObligations());
}

test "BindingContext - new obligations inside scope are not outer" {
    const allocator = std.testing.allocator;

    var parent = TestBindingContext.init(allocator);
    defer parent.deinit();

    try parent.set("outer_file", "opened!");

    var scoped_child = try TestBindingContext.inheritWithScope(&parent, allocator);
    defer scoped_child.deinit();

    // Add new obligation inside the scope
    try scoped_child.set("inner_file", "opened!");

    // outer_file is outer scope
    try std.testing.expect(scoped_child.isOuterScope("outer_file"));

    // inner_file is NOT outer scope (created inside)
    try std.testing.expect(!scoped_child.isOuterScope("inner_file"));

    // Both have uncleaned resources
    try std.testing.expect(scoped_child.hasUncleanedResources());
}

test "BindingContext - getOuterScopeObligations" {
    const allocator = std.testing.allocator;

    var parent = TestBindingContext.init(allocator);
    defer parent.deinit();

    try parent.set("outer1", "opened!");
    try parent.set("outer2", "opened!");

    var scoped_child = try TestBindingContext.inheritWithScope(&parent, allocator);
    defer scoped_child.deinit();

    try scoped_child.set("inner", "opened!");

    const outer_obligations = try scoped_child.getOuterScopeObligations(allocator);
    defer allocator.free(outer_obligations);

    // Should have 2 outer obligations
    try std.testing.expectEqual(@as(usize, 2), outer_obligations.len);

    // Total uncleaned is 3 (2 outer + 1 inner)
    const all_uncleaned = try scoped_child.getUncleanedResources(allocator);
    defer allocator.free(all_uncleaned);
    try std.testing.expectEqual(@as(usize, 3), all_uncleaned.len);
}

test "BindingContext - clearing outer scope obligation" {
    const allocator = std.testing.allocator;

    var parent = TestBindingContext.init(allocator);
    defer parent.deinit();

    try parent.set("file", "opened!");

    var scoped_child = try TestBindingContext.inheritWithScope(&parent, allocator);
    defer scoped_child.deinit();

    try std.testing.expect(scoped_child.isOuterScope("file"));

    // Clear the obligation (e.g., if we call dispose inside scope - which is allowed)
    scoped_child.clearCleanupObligation("file");

    // No longer has uncleaned resources
    try std.testing.expect(!scoped_child.hasUncleanedResources());
    try std.testing.expect(!scoped_child.hasOuterScopeObligations());
}

test "BindingContext - nested scope inheritance" {
    const allocator = std.testing.allocator;

    // Grandparent
    var gp = TestBindingContext.init(allocator);
    defer gp.deinit();
    try gp.set("gp_file", "opened!");

    // Parent with @scope
    var parent = try TestBindingContext.inheritWithScope(&gp, allocator);
    defer parent.deinit();
    try parent.set("parent_file", "opened!");

    // Child with another @scope
    var child = try TestBindingContext.inheritWithScope(&parent, allocator);
    defer child.deinit();
    try child.set("child_file", "opened!");

    // gp_file is outer to both parent and child
    try std.testing.expect(parent.isOuterScope("gp_file"));
    try std.testing.expect(child.isOuterScope("gp_file"));

    // parent_file is outer to child (because of second @scope)
    try std.testing.expect(!parent.isOuterScope("parent_file"));
    try std.testing.expect(child.isOuterScope("parent_file"));

    // child_file is not outer to anyone
    try std.testing.expect(!child.isOuterScope("child_file"));
}

test "BindingContext - state variable does not create obligation" {
    const allocator = std.testing.allocator;
    var ctx = TestBindingContext.init(allocator);
    defer ctx.deinit();

    // State variable (no obligation - it's a constraint, not a concrete state)
    try ctx.set("generic", "M'owned|borrowed");
    try std.testing.expect(!ctx.hasUncleanedResources());

    // Wildcard state variable
    try ctx.set("any", "F'_");
    try std.testing.expect(!ctx.hasUncleanedResources());
}

// ============================================================================
// Phantom State Mismatch Unit Tests
// Tests the full check() path with synthetic ASTs.
//
// ASTs must be built inline (not via helper function) because Zig struct
// literals reference stack-allocated arrays that become dangling after return.
// ============================================================================

test "PhantomSemanticChecker - state mismatch rejected" {
    const allocator = std.testing.allocator;

    var reporter = try errors.ErrorReporter.init(allocator, "test.kz", "// phantom test");
    defer reporter.deinit();

    var checker = try PhantomSemanticChecker.init(allocator, &reporter);
    defer checker.deinit();

    // Event A: ~event open_file {} | opened { file: *File[open] }
    var event_a_output_fields = [_]ast.Field{
        .{ .name = "file", .type = "*File", .phantom = "open" },
    };
    var event_a_branches = [_]ast.Branch{
        .{ .name = "opened", .payload = .{ .fields = &event_a_output_fields }, .is_deferred = false, .is_optional = false },
    };

    // Event B: ~event read_file { file: *File[closed] } | done {}
    var event_b_input_fields = [_]ast.Field{
        .{ .name = "file", .type = "*File", .phantom = "closed" },
    };
    var event_b_done_fields = [_]ast.Field{};
    var event_b_branches = [_]ast.Branch{
        .{ .name = "done", .payload = .{ .fields = &event_b_done_fields }, .is_deferred = false, .is_optional = false },
    };

    // Flow: ~open_file() | opened o |> read_file(file: o.file) | done |> _
    var terminal_cont = [_]ast.Continuation{
        .{
            .branch = "done",
            .binding = null,
            .condition = null,
            .node = .terminal,
            .indent = 2,
            .continuations = &[_]ast.Continuation{},
        },
    };
    var flow_args = [_]ast.Arg{
        .{ .name = "file", .value = "o.file" },
    };
    var flow_conts = [_]ast.Continuation{
        .{
            .branch = "opened",
            .binding = "o",
            .condition = null,
            .node = .{ .invocation = .{
                .path = .{ .module_qualifier = null, .segments = @constCast(&[_][]const u8{"read_file"}) },
                .args = &flow_args,
            } },
            .indent = 1,
            .continuations = &terminal_cont,
        },
    };

    var items = [_]ast.Item{
        .{ .event_decl = .{
            .path = .{ .module_qualifier = null, .segments = @constCast(&[_][]const u8{"open_file"}) },
            .input = .{ .fields = &[_]ast.Field{} },
            .branches = &event_a_branches,
            .annotations = @constCast(&[_][]const u8{}),
            .location = .{ .line = 1, .column = 0, .file = "test.kz" },
            .module = "input",
        } },
        .{ .event_decl = .{
            .path = .{ .module_qualifier = null, .segments = @constCast(&[_][]const u8{"read_file"}) },
            .input = .{ .fields = &event_b_input_fields },
            .branches = &event_b_branches,
            .annotations = @constCast(&[_][]const u8{}),
            .location = .{ .line = 5, .column = 0, .file = "test.kz" },
            .module = "input",
        } },
        .{ .flow = .{
            .invocation = .{
                .path = .{ .module_qualifier = null, .segments = @constCast(&[_][]const u8{"open_file"}) },
                .args = &[_]ast.Arg{},
            },
            .continuations = &flow_conts,
            .location = .{ .line = 8, .column = 0, .file = "test.kz" },
            .module = "input",
        } },
    };

    const program = ast.Program{
        .items = &items,
        .module_annotations = &[_][]const u8{},
        .main_module_name = "input",
        .allocator = allocator,
    };

    // check() should return ValidationFailed
    const result = checker.check(&program);
    try std.testing.expectError(error.ValidationFailed, result);

    // Verify error message mentions phantom state mismatch
    try std.testing.expect(reporter.errors.items.len > 0);
    const err_msg = reporter.errors.items[0].message;
    try std.testing.expect(std.mem.indexOf(u8, err_msg, "Phantom state mismatch") != null);
}

test "PhantomSemanticChecker - matching states accepted" {
    const allocator = std.testing.allocator;

    var reporter = try errors.ErrorReporter.init(allocator, "test.kz", "// phantom test");
    defer reporter.deinit();

    var checker = try PhantomSemanticChecker.init(allocator, &reporter);
    defer checker.deinit();

    // Event A: ~event open_file {} | opened { file: *File[open] }
    var event_a_output_fields = [_]ast.Field{
        .{ .name = "file", .type = "*File", .phantom = "open" },
    };
    var event_a_branches = [_]ast.Branch{
        .{ .name = "opened", .payload = .{ .fields = &event_a_output_fields }, .is_deferred = false, .is_optional = false },
    };

    // Event B: ~event read_file { file: *File[open] } | done {} — MATCHES [open]
    var event_b_input_fields = [_]ast.Field{
        .{ .name = "file", .type = "*File", .phantom = "open" },
    };
    var event_b_done_fields = [_]ast.Field{};
    var event_b_branches = [_]ast.Branch{
        .{ .name = "done", .payload = .{ .fields = &event_b_done_fields }, .is_deferred = false, .is_optional = false },
    };

    // Flow: ~open_file() | opened o |> read_file(file: o.file) | done |> _
    var terminal_cont = [_]ast.Continuation{
        .{
            .branch = "done",
            .binding = null,
            .condition = null,
            .node = .terminal,
            .indent = 2,
            .continuations = &[_]ast.Continuation{},
        },
    };
    var flow_args = [_]ast.Arg{
        .{ .name = "file", .value = "o.file" },
    };
    var flow_conts = [_]ast.Continuation{
        .{
            .branch = "opened",
            .binding = "o",
            .condition = null,
            .node = .{ .invocation = .{
                .path = .{ .module_qualifier = null, .segments = @constCast(&[_][]const u8{"read_file"}) },
                .args = &flow_args,
            } },
            .indent = 1,
            .continuations = &terminal_cont,
        },
    };

    var items = [_]ast.Item{
        .{ .event_decl = .{
            .path = .{ .module_qualifier = null, .segments = @constCast(&[_][]const u8{"open_file"}) },
            .input = .{ .fields = &[_]ast.Field{} },
            .branches = &event_a_branches,
            .annotations = @constCast(&[_][]const u8{}),
            .location = .{ .line = 1, .column = 0, .file = "test.kz" },
            .module = "input",
        } },
        .{ .event_decl = .{
            .path = .{ .module_qualifier = null, .segments = @constCast(&[_][]const u8{"read_file"}) },
            .input = .{ .fields = &event_b_input_fields },
            .branches = &event_b_branches,
            .annotations = @constCast(&[_][]const u8{}),
            .location = .{ .line = 5, .column = 0, .file = "test.kz" },
            .module = "input",
        } },
        .{ .flow = .{
            .invocation = .{
                .path = .{ .module_qualifier = null, .segments = @constCast(&[_][]const u8{"open_file"}) },
                .args = &[_]ast.Arg{},
            },
            .continuations = &flow_conts,
            .location = .{ .line = 8, .column = 0, .file = "test.kz" },
            .module = "input",
        } },
    };

    const program = ast.Program{
        .items = &items,
        .module_annotations = &[_][]const u8{},
        .main_module_name = "input",
        .allocator = allocator,
    };

    // check() should succeed — no errors
    try checker.check(&program);
    try std.testing.expectEqual(@as(usize, 0), reporter.errors.items.len);
}

test "PhantomSemanticChecker - cross-module state mismatch rejected" {
    const allocator = std.testing.allocator;

    var reporter = try errors.ErrorReporter.init(allocator, "test.kz", "// phantom test");
    defer reporter.deinit();

    var checker = try PhantomSemanticChecker.init(allocator, &reporter);
    defer checker.deinit();

    // Event A: ~event open_file {} | opened { file: *File[fs:open] }
    var event_a_output_fields = [_]ast.Field{
        .{ .name = "file", .type = "*File", .phantom = "fs:open" },
    };
    var event_a_branches = [_]ast.Branch{
        .{ .name = "opened", .payload = .{ .fields = &event_a_output_fields }, .is_deferred = false, .is_optional = false },
    };

    // Event B: ~event read_file { file: *File[mipmap:open] } | done {} — DIFFERENT MODULE
    var event_b_input_fields = [_]ast.Field{
        .{ .name = "file", .type = "*File", .phantom = "mipmap:open" },
    };
    var event_b_done_fields = [_]ast.Field{};
    var event_b_branches = [_]ast.Branch{
        .{ .name = "done", .payload = .{ .fields = &event_b_done_fields }, .is_deferred = false, .is_optional = false },
    };

    // Flow: ~open_file() | opened o |> read_file(file: o.file) | done |> _
    var terminal_cont = [_]ast.Continuation{
        .{
            .branch = "done",
            .binding = null,
            .condition = null,
            .node = .terminal,
            .indent = 2,
            .continuations = &[_]ast.Continuation{},
        },
    };
    var flow_args = [_]ast.Arg{
        .{ .name = "file", .value = "o.file" },
    };
    var flow_conts = [_]ast.Continuation{
        .{
            .branch = "opened",
            .binding = "o",
            .condition = null,
            .node = .{ .invocation = .{
                .path = .{ .module_qualifier = null, .segments = @constCast(&[_][]const u8{"read_file"}) },
                .args = &flow_args,
            } },
            .indent = 1,
            .continuations = &terminal_cont,
        },
    };

    var items = [_]ast.Item{
        .{ .import_decl = .{
            .path = "fs",
            .local_name = null,
            .location = .{ .line = 0, .column = 0, .file = "test.kz" },
            .module = "input",
        } },
        .{ .import_decl = .{
            .path = "mipmap",
            .local_name = null,
            .location = .{ .line = 0, .column = 0, .file = "test.kz" },
            .module = "input",
        } },
        .{ .event_decl = .{
            .path = .{ .module_qualifier = null, .segments = @constCast(&[_][]const u8{"open_file"}) },
            .input = .{ .fields = &[_]ast.Field{} },
            .branches = &event_a_branches,
            .annotations = @constCast(&[_][]const u8{}),
            .location = .{ .line = 1, .column = 0, .file = "test.kz" },
            .module = "input",
        } },
        .{ .event_decl = .{
            .path = .{ .module_qualifier = null, .segments = @constCast(&[_][]const u8{"read_file"}) },
            .input = .{ .fields = &event_b_input_fields },
            .branches = &event_b_branches,
            .annotations = @constCast(&[_][]const u8{}),
            .location = .{ .line = 5, .column = 0, .file = "test.kz" },
            .module = "input",
        } },
        .{ .flow = .{
            .invocation = .{
                .path = .{ .module_qualifier = null, .segments = @constCast(&[_][]const u8{"open_file"}) },
                .args = &[_]ast.Arg{},
            },
            .continuations = &flow_conts,
            .location = .{ .line = 8, .column = 0, .file = "test.kz" },
            .module = "input",
        } },
    };

    const program = ast.Program{
        .items = &items,
        .module_annotations = &[_][]const u8{},
        .main_module_name = "input",
        .allocator = allocator,
    };

    const result = checker.check(&program);
    try std.testing.expectError(error.ValidationFailed, result);

    try std.testing.expect(reporter.errors.items.len > 0);
    const err_msg = reporter.errors.items[0].message;
    try std.testing.expect(std.mem.indexOf(u8, err_msg, "Phantom state mismatch") != null);
}
