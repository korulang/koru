const std = @import("std");

pub fn build(__koru_b: *std.Build) void {
    const __koru_target = __koru_b.standardTargetOptions(.{});
    const __koru_optimize = __koru_b.standardOptimizeOption(.{});

    const __koru_exe = __koru_b.addExecutable(.{
        .name = "output",
        .root_module = __koru_b.createModule(.{
            .root_source_file = __koru_b.path("output_emitted.zig"),
            .target = __koru_target,
            .optimize = __koru_optimize,
        }),
    });

    // User module: user
    const user_build_0 = struct {
        fn call(b: *std.Build, exe: *std.Build.Step.Compile, target: std.Build.ResolvedTarget, optimize: std.builtin.OptimizeMode) void {
            _ = &b; _ = &exe; _ = &target; _ = &optimize; // Suppress unused warnings
const REL_TO_ROOT = "/usr/local/lib/koru";

// Errors module (needed by ast)
const errors_module = b.createModule(.{
    .root_source_file = .{ .cwd_relative = REL_TO_ROOT ++ "/src/errors.zig" },
    .target = target,
    .optimize = optimize,
});

// AST module
const ast_module = b.createModule(.{
    .root_source_file = .{ .cwd_relative = REL_TO_ROOT ++ "/src/ast.zig" },
    .target = target,
    .optimize = optimize,
});
ast_module.addImport("errors", errors_module);

// Add to executable
exe.root_module.addImport("ast", ast_module);

        }
    }.call;
user_build_0(__koru_b, __koru_exe, __koru_target, __koru_optimize);

    __koru_b.installArtifact(__koru_exe);
}
