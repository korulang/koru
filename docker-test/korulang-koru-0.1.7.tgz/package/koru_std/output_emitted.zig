// Access compiler flags from backend.zig via root import
const CompilerEnv = @import("root").CompilerEnv;

pub const main_module = struct {
    // CCP - Compiler Control Protocol (User Program Observability)
    // ==============================================================
    // This module provides basic event observability for Koru programs.
    //
    // Usage:
    //   ~import "$std/ccp"
    //   koruc my_app.kz --ccp
    //
    // Result: Program emits JSONL transition events to stdout at runtime
    //
    // Architecture:
    // - Uses Koru's universal tap system (~* -> *)
    // - Zero-cost when disabled (dead-strips at compile time)
    // - Self-governing: requires both import AND --ccp flag
    //
    // Related: docs/CCP.md
    const std = @import("std");
    // Note: Transition type is a magical ambient type emitted by the compiler
    // when any tap uses it. No need to define it here.
    // Event: Emit a transition event as JSONL to stdout
    // Marked [opaque] to prevent infinite recursion from universal tap
    pub const emit_transition_event = struct {
        pub const Input = struct {
            source: []const u8,
            branch: []const u8,
            destination: ?[]const u8,
            timestamp_ns: i128,
        };
        pub const Output = void;
        pub fn handler(__koru_event_input: Input) Output {
            // >>> PROC: emit_transition  [koru_std/ccp.kz:95]
            const source = __koru_event_input.source;
            const branch = __koru_event_input.branch;
            const destination = __koru_event_input.destination;
            const timestamp_ns = __koru_event_input.timestamp_ns;
            _ = &source;
            _ = &branch;
            _ = &destination;
            _ = &timestamp_ns;
            _ = &__koru_event_input;

                var buffer: [8192]u8 = undefined;
                var pos: usize = 0;

                // Build JSON manually (fast, no allocations)
                const prefix = "{\"type\":\"transition\",\"timestamp\":";
                @memcpy(buffer[pos..][0..prefix.len], prefix);
                pos += prefix.len;

                const timestamp = std.time.milliTimestamp();
                var timestamp_buf: [32]u8 = undefined;
                const timestamp_str = std.fmt.bufPrint(&timestamp_buf, "{d}", .{timestamp}) catch unreachable;
                @memcpy(buffer[pos..][0..timestamp_str.len], timestamp_str);
                pos += timestamp_str.len;

                const src_prefix = ",\"source\":\"";
                @memcpy(buffer[pos..][0..src_prefix.len], src_prefix);
                pos += src_prefix.len;
                @memcpy(buffer[pos..][0..source.len], source);
                pos += source.len;

                const branch_prefix = "\",\"branch\":\"";
                @memcpy(buffer[pos..][0..branch_prefix.len], branch_prefix);
                pos += branch_prefix.len;
                @memcpy(buffer[pos..][0..branch.len], branch);
                pos += branch.len;

                buffer[pos] = '"';
                pos += 1;

                if (destination) |dest| {
                    const dest_prefix = ",\"destination\":\"";
                    @memcpy(buffer[pos..][0..dest_prefix.len], dest_prefix);
                    pos += dest_prefix.len;
                    @memcpy(buffer[pos..][0..dest.len], dest);
                    pos += dest.len;
                    buffer[pos] = '"';
                    pos += 1;
                } else {
                    const dest_null = ",\"destination\":null";
                    @memcpy(buffer[pos..][0..dest_null.len], dest_null);
                    pos += dest_null.len;
                }


                const dur_prefix = ",\"timestamp_ns\":";
                @memcpy(buffer[pos..][0..dur_prefix.len], dur_prefix);
                pos += dur_prefix.len;
                var dur_buf: [32]u8 = undefined;
                const dur_str = std.fmt.bufPrint(&dur_buf, "{d}", .{timestamp_ns}) catch unreachable;
                @memcpy(buffer[pos..][0..dur_str.len], dur_str);
                pos += dur_str.len;

                const suffix = "}\n";
                @memcpy(buffer[pos..][0..suffix.len], suffix);
                pos += suffix.len;

                // Write to stdout (compiler diagnostics go to stderr)
                std.debug.print("{s}", .{buffer[0..pos]});

        }
    };
    // UNIVERSAL TAP: Observe ALL event transitions in the program
    //
    // This tap fires for every event transition:
    // - User code events (any ~event in your program)
    // - Standard library events (when used)
    //
    // The Transition metatype provides:
    // - source: Source event name (e.g., "fetch", "process")
    // - branch: Branch name taken (e.g., "success", "error")
    // - destination: Next event in flow (null for terminal transitions)
    // - timestamp_ns: Execution time (null unless profiling enabled)
    //
    // Self-governing: Only fires when --ccp flag is set AND this module is imported
    pub fn koru_start_flow() void {
        const result_0 = koru_koru.start_event.handler(.{  });
        const result_0_done = result_0.done;
        _ = &result_0_done;
        {
            const _profile_b470b4a39edcfd44_1 = taps.Profile{
                .source = "koru:start",
                .destination = null,
                .branch = "done",
                .timestamp_ns = __koru_std.time.nanoTimestamp(),
            };
            _ = &_profile_b470b4a39edcfd44_1;
            const result_1 = main_module.emit_transition_event.handler(.{ .source = _profile_b470b4a39edcfd44_1.source, .branch = _profile_b470b4a39edcfd44_1.branch, .destination = _profile_b470b4a39edcfd44_1.destination, .timestamp_ns = _profile_b470b4a39edcfd44_1.timestamp_ns });
            _ = &result_1;
        }
    }
    pub fn koru_end_flow() void {
        const result_0 = koru_koru.end_event.handler(.{  });
        const result_0_done = result_0.done;
        _ = &result_0_done;
        {
            const _profile_b470b4a39edcfd44_3 = taps.Profile{
                .source = "koru:end",
                .destination = null,
                .branch = "done",
                .timestamp_ns = __koru_std.time.nanoTimestamp(),
            };
            _ = &_profile_b470b4a39edcfd44_3;
            const result_1 = main_module.emit_transition_event.handler(.{ .source = _profile_b470b4a39edcfd44_3.source, .branch = _profile_b470b4a39edcfd44_3.branch, .destination = _profile_b470b4a39edcfd44_3.destination, .timestamp_ns = _profile_b470b4a39edcfd44_3.timestamp_ns });
            _ = &result_1;
        }
    }
};

pub const koru_std = struct {
    // Koru Standard Library: Root
    // Auto-imported when any $std/* module is imported
    // Transitively imports control to make keywords (like ~if, ~for) available
};
pub const koru_koru = struct {
    pub const start_event = struct {
        pub const Input = struct {
        };
        pub const Output = union(enum) {
            done: struct {
            },
        };
        pub fn handler(__koru_event_input: Input) Output {
            _ = &__koru_event_input;
            return .{ .done = .{} };
        }
    };
    pub const end_event = struct {
        pub const Input = struct {
        };
        pub const Output = union(enum) {
            done: struct {
            },
        };
        pub fn handler(__koru_event_input: Input) Output {
            _ = &__koru_event_input;
            return .{ .done = .{} };
        }
    };
};
const __koru_std = @import("std");
// Taps namespace - compiler infrastructure for event observation
const taps = struct {
    // Profile meta-type - string-based with timing (32+ bytes)
    // For performance profiling and timeline reconstruction
    pub const Profile = struct {
        source: []const u8,           // interned string
        destination: ?[]const u8,     // interned string (null for terminal)
        branch: []const u8,           // interned string
        timestamp_ns: i128,           // nanoseconds since epoch (runtime capture)
    };

};

pub fn main() void {
    main_module.koru_start_flow();
    main_module.koru_end_flow();
}

test {
    @import("std").testing.refAllDeclsRecursive(@This());
}
