# Koru

The event continuation language.

## Install

```bash
npm install -g @korulang/koru
```

## Dependencies

Koru needs **[Zig](https://ziglang.org/download/) 0.15+**

Install it however you like:
- [ziglang.org/download](https://ziglang.org/download/)
- `brew install zig` (macOS)
- `pacman -S zig` (Arch)

Or let koruc install it for you:

```bash
koruc deps install
```

Then add the path it tells you to your shell, and verify:

```bash
koruc deps
```

```
Dependencies:

  zig ✓ 0.15.1

Ready!
```

## Usage

```bash
koruc your-file.kz
```

## Learn More

- [korulang.org](https://korulang.org) - Documentation
- [Getting Started](https://korulang.org/learn/getting-started)
- [GitHub](https://github.com/korulang/koru)
